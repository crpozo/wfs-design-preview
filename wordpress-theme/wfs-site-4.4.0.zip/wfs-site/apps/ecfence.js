ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(MaterialPage,{slug:"ecfence"}));
