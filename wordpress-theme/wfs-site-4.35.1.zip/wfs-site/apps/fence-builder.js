/* Configurador paso a paso, para cercas y para portones.
   Todo lo que ofrece sale de lo que existe de verdad: las imagenes de
   assets/profiles y assets/, y las fichas tecnicas de assets/specs. Cuando una
   combinacion tiene plano, se ofrece; cuando no, se dice. */
(function () {
  /* Modulo montable. Antes era una pagina entera; ahora se instancia dentro de
     cualquier contenedor y se puede fijar el material o el tipo de porton, para
     que en la pagina del aluminio solo se vean variantes de aluminio. */

  /* ── Materiales ──────────────────────────────────────────────────────────
     styles.img es la clave de union con las fichas de material del sitio:
     alli las etiquetas son otras ("3-Rail" frente a "3-Rail Rake Bottom") y la
     imagen es lo unico que coincide siempre.
     slug es la parte que aparece en el nombre de la ficha tecnica. */
  var MAT = {
    aluminum: {
      name: 'Aluminum', tag: 'Powder-coat · 6063-T6', key: 'alum',
      styleLabel: 'Profile',
      styles: [
        { label: '2-Rail Smooth Bottom',      img: 'aluminum-2-rail-smooth', slug: '2rail-smooth-bottom',     sub: 'Flush bottom rail, clean line' },
        { label: '2-Rail Smooth, 3" Spacing', img: 'aluminum-2-rail-smooth', slug: '2rail-smooth-bottom-3in', sub: 'Tighter picket spacing' },
        { label: '3-Rail Rake Bottom',        img: 'aluminum-3-rail-rake',   slug: '3rail-rake-bottom',       sub: 'Pickets extend past the bottom rail' },
        { label: '3-Rail Puppy Picket',       img: 'aluminum-puppy-picket',  slug: '3rail-puppy-picket',      sub: 'Extra pickets low down, for pets' },
        { label: 'Pool Code',                 img: 'aluminum-pool-code',     slug: null, sub: 'Non-climbable, FBC barrier' },
        { label: 'Spear Top',                 img: 'aluminum-spear-top',     slug: null, sub: 'Ornamental spear finials' },
        { label: '4-Rail Custom',             img: 'aluminum-custom',        slug: null, sub: 'Taller runs and custom configurations' }
      ],
      heights: ["4'", "5'", "6'"],
     
      colors: [ { label: 'Black', hex: '#1c1c1c' }, { label: 'Bronze', hex: '#4a3728' }, { label: 'White', hex: '#f2f2ee' } ],
      /* El grado (residencial o comercial) se quito del configurador: no cambia
         nada de lo que se ve, solo el grosor del picket, y obligaba a decidir
         algo tecnico antes de poder pedir precio. La ficha tecnica que se
         ofrece al final prueba primero la residencial, que es la habitual. */
      grades: []
    },
    'chain-link': {
      name: 'Chain Link', tag: 'Galvanized + vinyl-coated', key: 'chainlink',
      styleLabel: 'Finish',
      styles: [
        { label: 'Galvanized',       img: 'chainlink-galvanized',  slug: null, sub: 'ASTM A392 zinc coat' },
        { label: 'Black PVC-coated', img: 'chainlink-black',       slug: null, sub: 'Reads cleaner on residential' },
        { label: 'Green PVC-coated', img: 'chainlink-green',       slug: null, sub: 'Blends into landscaping' },
        { label: 'Heavy Gauge',      img: 'chainlink-heavy-gauge', slug: null, sub: 'For industrial perimeters' }
      ],
      heights: ["4'", "5'", "6'"], colors: [], grades: []
    },
    vinyl: {
      name: 'Vinyl / PVC', tag: 'Catalyst-extruded PVC', key: 'vinyl',
      styleLabel: 'Profile',
      styles: [
        { label: 'Privacy',      img: 'vinyl-privacy',      slug: null, sub: 'Solid panel, no gaps' },
        { label: 'Semi-Privacy', img: 'vinyl-semi-privacy', slug: null, sub: 'Airflow with partial screening' },
        { label: 'Picket',       img: 'vinyl-picket',       slug: null, sub: 'Open front-yard look' },
        /* Ranch rail solo se vende en 4 pies. */
        { label: 'Ranch Rail',   img: 'vinyl-ranch-rail',   slug: null, sub: 'Three rail, acreage', heights: ["4'"] }
      ],
      heights: ["4'", "5'", "6'"],
      colors: [ { label: 'White', hex: '#f2f2ee' }, { label: 'Tan', hex: '#d6c9ae' }, { label: 'Gray', hex: '#8b8b88' } ],
      grades: []
    },
    metal: {
      name: 'Metal / DuraFence', tag: 'Aluminum board privacy', key: 'metal',
      styleLabel: 'Style',
      styles: [
        { label: 'Modern',   img: 'metal-modern',   slug: null, sub: 'Wide-rib corrugated panel' },
        { label: 'Original', img: 'metal-original', slug: null, sub: 'Narrow-rib corrugated panel' },
        { label: 'P1',       img: 'metal-p1',       slug: null, sub: 'Medium-rib corrugated panel' }
      ],
      /* Rieles: la pagina de metal enseña obras a 2 y a 3 rieles, asi que se
         elige. Van por detras de la chapa, y en el 3D se ven desde el jardin. */
      rails: ['2-Rail', '3-Rail'],
      heights: ["6'", "8'"],
      colors: [ { label: 'White', hex: '#f2f2ee' }, { label: 'Black', hex: '#1c1c1c' }, { label: 'Bronze', hex: '#4a3728' }, { label: 'Woodgrain', hex: '#7a5c3e' } ],
      grades: []
    },
    ecfence: {
      name: 'EC Fence', tag: 'Self-mating galvanized steel', key: 'ecfence',
      styleLabel: 'Color',
      styles: [
        { label: 'Bronze',        img: 'ecfence-bronze', slug: null, sub: 'Warm dark finish' },
        { label: 'White',         img: 'ecfence-white',  slug: null, sub: 'Bright coastal finish' }
      ],
      heights: ["6'"], colors: [], grades: []
    }
  };

  /* ── Tipos de porton ─────────────────────────────────────────────────── */
  var GATES = [
    { id: 'single',     label: 'Single Swing',   img: 'https://crpozo.github.io/wfs-design-preview/assets/gate-single-swing.jpg', sub: 'Walk and entry gates' },
    { id: 'double',     label: 'Double Swing',   img: 'https://crpozo.github.io/wfs-design-preview/assets/gate-double.jpg',       sub: 'Driveways and wide openings' },
    { id: 'sliding',    label: 'Sliding',        img: 'https://crpozo.github.io/wfs-design-preview/assets/gate-sliding.jpg',      sub: 'Track-mounted, tight driveways' },
    { id: 'cantilever', label: 'Cantilever',     img: 'https://crpozo.github.io/wfs-design-preview/assets/gate-cantilever.jpg',   sub: 'No ground track, up to 30 ft' },
    { id: 'rolling',    label: 'Rolling',        img: 'https://crpozo.github.io/wfs-design-preview/assets/gate-rolling.jpg',      sub: 'Rubber wheels, uneven ground' }
  ];


  /* Variantes de color de las FOTOS de porton, en assets/gates/tinted.
     Es la misma foto con el panel repintado, no otra foto: al cambiar el color
     se ve el mismo porton pintado de otro color.
     Las genera wordpress-theme/tools/tint-gates.py.
     Falta a proposito pvc-privacy-cantilever-gate-white: en esa foto el cielo,
     las nubes, el vinilo y el hormigon comparten tono y no hay umbral que
     separe la valla. Haria falta una foto de estudio de ese porton. */
  var TINTADO_PORTON = {
    'DOUBLE_GATE-gray': 1,
    'DOUBLE_GATE-tan': 1,
    'DOUBLE_GATE-white': 1,
    'gate-single-custom-pvc-gray': 1,
    'gate-single-custom-pvc-tan': 1,
    'gate-single-custom-pvc-white': 1,
    'gate-single-matching-ecfence-black': 1,
    'gate-single-matching-ecfence-bronze': 1,
    'gate-single-matching-ecfence-white': 1,
    'gate-single-matching-ecfence-woodgrain': 1,
    'pvc-gate-sand-gray': 1,
    'pvc-gate-sand-tan': 1,
    'pvc-gate-sand-white': 1
  };

  /* ── fotos de porton ──────────────────────────────────────────────────────
     En una pagina de porton no puede salir un panel de cerca: el cliente esta
     comprando la hoja, no el tramo. Aqui esta lo que hay fotografiado de
     verdad en assets, y se busca de lo mas concreto a lo mas general:
     tipo+acabado, acabado, tipo, y por ultimo el del material.
     Ojo con las genericas: gate-single-swing / sliding / cantilever / rolling
     son de chain link, y gate-double es de vinilo blanco. Por eso van dentro
     del material que les toca y no como comodin de todos. */
  var PORTONES = {
    aluminum: {
      def: 'https://crpozo.github.io/wfs-design-preview/assets/projects/alum-4-rail-smooth-bottom-custom-gate-black.jpg'
    },
    'chain-link': {
      'sliding|Galvanized':          'https://crpozo.github.io/wfs-design-preview/assets/gate-sliding.jpg',
      'rolling|Galvanized':          'https://crpozo.github.io/wfs-design-preview/assets/gate-rolling.jpg',
      'cantilever|Black PVC-coated': 'https://crpozo.github.io/wfs-design-preview/assets/gate-cantilever.jpg',
      'Galvanized':                  'https://crpozo.github.io/wfs-design-preview/assets/projects/cl-swing-gate-galv-4.jpg',
      'Black PVC-coated':            'https://crpozo.github.io/wfs-design-preview/assets/projects/cl-gate-black.jpg',
      single:     'https://crpozo.github.io/wfs-design-preview/assets/gate-single-swing.jpg',
      sliding:    'https://crpozo.github.io/wfs-design-preview/assets/gate-sliding.jpg',
      cantilever: 'https://crpozo.github.io/wfs-design-preview/assets/gate-cantilever.jpg',
      rolling:    'https://crpozo.github.io/wfs-design-preview/assets/gate-rolling.jpg',
      def:        'https://crpozo.github.io/wfs-design-preview/assets/projects/cl-gate-black.jpg'
    },
    vinyl: {
      'cantilever|White': 'https://crpozo.github.io/wfs-design-preview/assets/projects/pvc-privacy-cantilever-gate-white.jpg',
      'double|White':     'https://crpozo.github.io/wfs-design-preview/assets/projects/pvc-double-gate-white.jpg',
      'White':            'https://crpozo.github.io/wfs-design-preview/assets/projects/pvc-privacy-gate-white.jpg',
      'Tan':              'https://crpozo.github.io/wfs-design-preview/assets/projects/pvc-gate-sand.jpg',
      def:                'https://crpozo.github.io/wfs-design-preview/assets/projects/pvc-privacy-gate-white.jpg'
    },
    /* DuraFence es tabla horizontal, igual que esta hoja. No hay foto propia
       de porton DuraFence; esta se le parece mucho mas que cualquier picket. */
    metal:   { def: 'https://crpozo.github.io/wfs-design-preview/assets/projects/gate-single-matching-ecfence.webp' },
    ecfence: { def: 'https://crpozo.github.io/wfs-design-preview/assets/projects/gate-single-matching-ecfence.webp' }
  };

  /**
   * La mejor foto de porton para un material.
   *
   * El acabado es s.color donde existe, y s.style donde el color ES el paso de
   * estilo (chain link, EC Fence).
   */
  function fotoPorton(mat, tipo, acabado) {
    var tabla = PORTONES[mat];
    if (!tabla) { return null; }
    /* El TIPO manda sobre el acabado: en la pagina de Cantilever, buscar
       primero por acabado devolvia una foto de porton batiente galvanizado,
       que es cualquier cosa menos un cantilever. */
    var claves = [tipo + '|' + acabado, tipo, acabado, 'def'];
    for (var i = 0; i < claves.length; i++) {
      if (claves[i] && tabla[claves[i]]) { return tabla[claves[i]]; }
    }
    return null;
  }

  /* Fichas que existen en assets/specs. Si la combinacion no esta, se dice en
     vez de ofrecer un enlace roto. */
  var SHEETS = {
    'alum-4ft-com-2rail-smooth-bottom-3in-panel': 1, 'alum-4ft-res-2rail-smooth-bottom-3in-panel': 1,
    'alum-4ft-res-2rail-smooth-bottom-panel': 1, 'alum-4ft-res-3rail-puppy-picket-panel': 1,
    'alum-4ft-res-3rail-rake-bottom-panel': 1, 'alum-5ft-res-3rail-rake-bottom-panel': 1,
    'alum-6ft-com-3rail-rake-bottom-panel': 1,
    'alum-4x4-com-2rail-smooth-bottom-3in-gate': 1, 'alum-4x4-res-2rail-smooth-bottom-gate': 1,
    'alum-4x4-res-3rail-puppy-picket-gate': 1, 'alum-4x4-res-3rail-rake-bottom-gate': 1,
    'alum-4x5-com-2rail-smooth-bottom-3in-gate': 1, 'alum-4x5-res-2rail-smooth-bottom-gate': 1,
    'alum-4x5-res-3rail-puppy-picket-gate': 1, 'alum-4x5-res-3rail-rake-bottom-gate': 1,
    'alum-5x4-res-3rail-rake-bottom-gate': 1, 'alum-5x5-res-3rail-rake-bottom-gate': 1,
    'alum-6x4-com-3rail-rake-bottom-gate': 1, 'alum-6x5-com-3rail-rake-bottom-gate': 1,
    'chainlink-gate-single': 1, 'chainlink-gate-double': 1, 'chainlink-gate-cantilever': 1
  };


  /* ── Variantes de color ──────────────────────────────────────────────────
     Generadas desde el MISMO dibujo del perfil, cambiandole solo el color: en
     assets/profiles/tinted, una por perfil y acabado. Asi al cambiar de color
     no salta a otra escena, se ve la misma valla pintada de otro color.
     Los claros van sobre fondo gris, que en blanco sobre blanco no se veria. */
  var TINTED = {
    'aluminum-2-rail-smooth-black': 1,
    'aluminum-2-rail-smooth-bronze': 1,
    'aluminum-2-rail-smooth-white': 1,
    'aluminum-3-rail-rake-black': 1,
    'aluminum-3-rail-rake-bronze': 1,
    'aluminum-3-rail-rake-white': 1,
    'aluminum-custom-black': 1,
    'aluminum-custom-bronze': 1,
    'aluminum-custom-white': 1,
    'aluminum-pool-code-black': 1,
    'aluminum-pool-code-bronze': 1,
    'aluminum-pool-code-white': 1,
    'aluminum-puppy-picket-black': 1,
    'aluminum-puppy-picket-bronze': 1,
    'aluminum-puppy-picket-white': 1,
    'aluminum-spear-top-black': 1,
    'aluminum-spear-top-bronze': 1,
    'aluminum-spear-top-white': 1,
    'metal-modern-black': 1,
    'metal-modern-bronze': 1,
    'metal-modern-white': 1,
    'metal-modern-woodgrain': 1,
    'metal-original-black': 1,
    'metal-original-bronze': 1,
    'metal-original-white': 1,
    'metal-original-woodgrain': 1,
    'metal-p1-black': 1,
    'metal-p1-bronze': 1,
    'metal-p1-white': 1,
    'metal-p1-woodgrain': 1,
    'vinyl-picket-gray': 1,
    'vinyl-picket-white': 1,
    'vinyl-privacy-gray': 1,
    'vinyl-privacy-white': 1,
    'vinyl-ranch-rail-gray': 1,
    'vinyl-ranch-rail-white': 1,
    'vinyl-semi-privacy-gray': 1,
    'vinyl-semi-privacy-white': 1
  };
  var COLOR_SLUG = { 'Black':'black', 'Bronze':'bronze', 'White':'white',
                     'Woodgrain':'woodgrain', 'Gray':'gray', 'Tan':'tan' };
  /* Los acabados claros se generaron sobre gris para que se vieran; el resto
     sobre claro. El marco copia ese fondo, asi al escalar el dibujo por altura
     no se ve el borde de la imagen. */
  /* Fondo del marco = fondo real de la imagen que se este mostrando, medido en
     el archivo. Sin igualarlo se veia el recuadro de la imagen recortado dentro
     del marco. Las originales vienen sobre blanco puro; las variantes se
     generaron sobre gris claro, y las blancas sobre gris medio para que la
     pieza blanca se distinga. */
  var FONDO_ORIGINAL = '#ffffff';
  var FONDO_TINTE    = '#ebebeb';
  var FONDO_BLANCO   = '#787e8a';
  var FONDO_FOTO     = '#e9eaec';


  var ORDER = ['aluminum', 'chain-link', 'vinyl', 'metal', 'ecfence'];

  /* Que material se vende para cada tipo de porton. Sale del texto de cada
     pagina de porton (la tarjeta de materiales), pero vive AQUI y no alli para
     que el configurador suelto de fence-builder.html aplique la misma regla:
     alli no llega nada de page-gate.jsx y ofrecia aluminio para un rolling.
       sliding y cantilever: "chain link, vinyl, metal, and EC Fence" - sin aluminio
       rolling: "chain link is the recommended build" */
  var GATE_MATS = {
    single:     ORDER,
    double:     ORDER,
    sliding:    ['chain-link', 'vinyl', 'metal', 'ecfence'],
    cantilever: ['chain-link', 'vinyl', 'metal', 'ecfence'],
    rolling:    ['chain-link']
  };

  /* El visualizador 3D pesa medio mega: no se descarga hasta que alguien
     pulsa el boton, y una sola vez por pagina aunque haya varios
     configuradores. La ruta la puede fijar el tema de WordPress, donde el
     archivo no cuelga de la raiz del sitio. */
  var carga3D = null;
  function cargar3D() {
    if (window.WFS3D) { return Promise.resolve(); }
    if (carga3D) { return carga3D; }
    carga3D = new Promise(function (ok, mal) {
      var sc = document.createElement('script');
      sc.src = window.WFS3D_SRC || 'fence-3d.js';
      sc.onload = function () { window.WFS3D ? ok() : mal(new Error('sin WFS3D')); };
      sc.onerror = function () { carga3D = null; mal(new Error('no carga')); };
      document.head.appendChild(sc);
    });
    return carga3D;
  }

  var ESQUELETO =
    '<div class="bld__grid">' +
      '<div class="bld__steps"></div>' +
      '<aside class="bld__stage">' +
        '<div class="bld__frame">' +
          '<span class="bld__badge"></span>' +
          '<span class="bld__media"><img class="bld__img" alt="Fence preview" decoding="async" crossorigin="anonymous"></span>' +
          '<div class="bld__escala"></div>' +
        '</div>' +
        '<div class="bld__spec"><dl></dl></div>' +
        '<div class="bld__acciones">' +
          '<button class="bld__3d" type="button" disabled>' +
            '<span class="bld__3d-ico" aria-hidden="true"></span>View in 3D' +
          '</button>' +
          '<p class="bld__3d-pie">See it on a real home, with the yard around it.</p>' +
        '</div>' +
      '</aside>' +
    '</div>';

  /* Cuanto fondo blanco hay bajo el producto en la imagen, para plantar la
     cota y la persona en la MISMA base que el producto y no en el borde de la
     foto: el margen varia del 8% de un recorte de perfil al 24% de una foto de
     estudio con su sombra, asi que se mide en la propia imagen (escaneando una
     miniatura desde abajo hasta el primer pixel que no es fondo).
     Si el canvas esta "tainted" porque la imagen viene de otro dominio (los
     assets en produccion), se cae a una constante razonable. */
  var MARGEN_CACHE = {};
  function medirMargenes(img) {
    var src = img.currentSrc || img.src;
    if (src in MARGEN_CACHE) { return MARGEN_CACHE[src]; }
    var v = null;
    try {
      var nw = img.naturalWidth, nh = img.naturalHeight;
      if (nw && nh) {
        var w = 64, h = Math.max(8, Math.round(nh * 64 / nw));
        var c = document.createElement('canvas');
        c.width = w; c.height = h;
        var g = c.getContext('2d', { willReadFrequently: true });
        g.drawImage(img, 0, 0, w, h);
        var d = g.getImageData(0, 0, w, h).data;
        /* Fondo: media 3x3 en cada esquina. Si las cuatro coinciden, la foto
           tiene fondo liso (estudio) y sabemos de que color pintarlo. */
        var esquina = function (x0, y0) {
          var r = 0, g2 = 0, b = 0;
          for (var dy = 0; dy < 3; dy++) {
            for (var dx = 0; dx < 3; dx++) {
              var q = ((y0 + dy) * w + (x0 + dx)) * 4;
              r += d[q]; g2 += d[q + 1]; b += d[q + 2];
            }
          }
          return [r / 9, g2 / 9, b / 9];
        };
        var es = [esquina(0, 0), esquina(w - 3, 0), esquina(0, h - 3), esquina(w - 3, h - 3)];
        var uniforme = true;
        for (var a = 1; a < 4; a++) {
          for (var ch = 0; ch < 3; ch++) {
            if (Math.abs(es[a][ch] - es[0][ch]) > 26) { uniforme = false; }
          }
        }
        var fondo = uniforme
          ? [Math.round((es[0][0] + es[3][0]) / 2), Math.round((es[0][1] + es[3][1]) / 2),
             Math.round((es[0][2] + es[3][2]) / 2)]
          : null;
        /* Producto = lo que NO es fondo. Antes se buscaban pixeles "oscuros"
           y con un producto blanco sobre fondo gris (las variantes tintadas
           en blanco) el fondo contaba como producto: la cerca parecia ocupar
           toda la imagen, se escalaba de menos y quedaba mas baja que la
           cota. Ahora se compara con el color de fondo medido; si no hay
           fondo liso, se cae al criterio de oscuridad. */
        var esProducto = function (i) {
          if (fondo) {
            return Math.abs(d[i] - fondo[0]) + Math.abs(d[i + 1] - fondo[1]) + Math.abs(d[i + 2] - fondo[2]) > 48;
          }
          return d[i] < 200 || d[i + 1] < 200 || d[i + 2] < 200;
        };
        var fila = function (y) {
          var n = 0;
          for (var x = 0; x < w; x++) { if (esProducto((y * w + x) * 4)) { n++; } }
          return n >= 2;          /* dos pixeles: una mota no es el producto */
        };
        var inf = null, sup = null;
        for (var y = h - 1; y >= 0; y--) { if (fila(y)) { inf = (h - 1 - y) / h; break; } }
        for (var y2 = 0; y2 < h; y2++) { if (fila(y2)) { sup = y2 / h; break; } }
        if (inf !== null && sup !== null && inf + sup < 0.9) {
          v = { inf: inf, sup: sup, fondo: fondo };
        }
      }
    } catch (e) { v = null; }
    MARGEN_CACHE[src] = v;
    return v;
  }

  function crear(root, opts) {
  opts = opts || {};
  root.innerHTML = ESQUELETO;

  /* Lo que viene fijado por la pagina no se pregunta. */
  /* Fijado = no se puede cambiar y desaparece como paso. Preseleccionado =
     viene puesto pero sigue a la vista. En una pagina de porton el tipo va
     PRESELECCIONADO, no fijado: el primer paso de un porton es que porton es,
     no de que esta hecho. Fijarlo dejaba "Material" como paso 01. */
  var FIJO = { product: opts.product || null, mat: opts.material || null, gate: opts.gate || null };

  /* El paso que la pagina ya contesta llega PLEGADO: estas en la ficha de
     Single Swing, no hace falta que el paso 01 ocupe cinco tarjetas para
     decirtelo. Se abre con "Change". */
  var PLEGABLE = opts.gateInicial ? 'gate' : null;
  var reabierto = {};

  var s = { product: FIJO.product, gate: FIJO.gate || opts.gateInicial || null, mat: FIJO.mat,
            opcion: null, ancho: null, marco: null, style: null, rails: null, height: null, color: null };

  /* Que ofrece cada tipo de porton, segun lo que dice SU pagina: las tarjetas
     de obra y los materiales que se venden para ese porton. Un corredero no
     lleva aluminio y un rolling es chain link, y ofrecerlos era prometer algo
     que la pagina no vende. */
  var GATES_CFG = opts.gates || {};
  function cfg() { return GATES_CFG[s.gate] || {}; }
  /* Las tarjetas de obra son contenido de la pagina y llegan desde ella. */
  function opciones() { return cfg().opciones || []; }
  /* La tarjeta elegida puede traer su acabado ya fijado: es el que enseña su
     propia foto. En ese caso no hay nada que preguntar. */
  function estiloDeOpcion() {
    var o = opciones().filter(function (x) { return x.name === s.opcion; })[0];
    return o && o.estilo ? o.estilo : null;
  }

  function matsPermitidos() {
    var lista = GATE_MATS[s.gate];
    if (!lista || !lista.length) { return ORDER; }
    return ORDER.filter(function (id) { return lista.indexOf(id) !== -1; });
  }

  /* Un porton sin tarjetas arranca ya con su material por defecto, para que
     Height y Color tengan de donde salir sin pedirle nada al visitante. Va
     AQUI y no junto a la declaracion de s: alli GATES_CFG todavia no tiene
     valor y cfg() reventaba. */
  if (s.product === 'gate' && s.gate && !s.mat && (!opciones().length || soloTipo())) {
    s.mat = cfg().matDefecto || 'chain-link';
    s.style = MAT[s.mat] ? MAT[s.mat].styles[0].label : null;
  }

  var $ = function (clase) { return root.querySelector('.bld__' + clase); };

  var esc = function (t) { return String(t).replace(/[&<>"]/g, function (c) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]; }); };
  var m = function () { return s.mat ? MAT[s.mat] : null; };
  var styleObj = function () {
    return m() ? (m().styles.filter(function (x) { return x.label === s.style; })[0] || null) : null; };
  var gateObj = function () { return GATES.filter(function (g) { return g.id === s.gate; })[0] || null; };

  /* Se puede llegar desde una tarjeta:
     ?m=aluminum&p=aluminum-3-rail-rake   (perfil de una pagina de material)
     ?g=double                            (tipo de porton) */
  (function precargar() {
    var q = new URLSearchParams(location.search);
    var g = q.get('g'), mat = q.get('m'), img = q.get('p');
    if (g && GATES.filter(function (x) { return x.id === g; })[0]) {
      s.product = 'gate'; s.gate = g;
    } else if (mat && MAT[mat]) {
      s.product = 'fence'; s.mat = mat;
      if (img) {
        var enc = MAT[mat].styles.filter(function (x) { return x.img === img; })[0];
        if (enc) { s.style = enc.label; }
      }
    }
  })();

  /* Los pasos se derivan del estado: un porton pide ancho, una cerca no; el
     color y el grado solo salen donde el material los ofrece. */
  function soloTipo() { return s.product === 'gate' && !!s.gate && s.gate !== 'single'; }
  function steps() {
    var out = [];
    if (!FIJO.product) { out.push({ key: 'product', title: 'What are you building' }); }
    if (!s.product) { return out; }
    if (s.product === 'gate' && !FIJO.gate) { out.push({ key: 'gate', title: 'Gate type' }); }
    if (!s.gate && s.product === 'gate') { return out; }
    /* En portones que NO son single swing solo se elige el tipo y la altura:
       las opciones y el acabado se enseñan como galeria en la pagina, no en
       el configurador, y el 3D monta el tipo de porton con el material por
       defecto de esa pagina. */
    if (soloTipo()) { out.push({ key: 'height', title: 'Height' }); return out; }
    /* Solo si esa pagina trae tarjetas de obra. Cantilever y rolling no
       tienen: sus tarjetas son componentes, no variantes. */
    if (s.product === 'gate' && opciones().length) { out.push({ key: 'opcion', title: 'Gate option' }); }
    /* El material NO es un paso en portones: lo que se elige ahi es que porton
       es, y cada opcion trae el suyo. En una cerca si lo es, porque la cerca
       ES el material. */
    if (s.product !== 'gate' && !FIJO.mat) { out.push({ key: 'mat', title: 'Material' }); }
    if (!s.mat) { return out; }
    /* El perfil no se pregunta en un porton: es del material, y en un porton el
       material viene con la tarjeta.
       La excepcion es chain link y EC Fence, donde ese paso NO es el perfil
       sino el ACABADO (galvanizado, negro, verde). Quitarlo dejaba un porton
       cantilever que solo podia ser galvanizado, porque ademas esos materiales
       tienen la lista de colores vacia y tampoco tenian paso de color. */
    /* Y si la tarjeta ya fijo el acabado (Standard Walk Gate es el porton negro
       de su foto), preguntarlo era inventarse variantes que nadie ha dicho que
       existan. Solo se pregunta donde no hay tarjeta que lo conteste. */
    if (s.product !== 'gate' || (!(m().colors && m().colors.length) && !estiloDeOpcion())) {
      out.push({ key: 'style', title: m().styleLabel });
    }
    if (s.product !== 'gate' && m().rails) { out.push({ key: 'rails', title: 'Rails' }); }
    out.push({ key: 'height', title: 'Height' });
    if (m().colors && m().colors.length) { out.push({ key: 'color', title: 'Color' }); }
    return out;
  }
  function value(k) {
    if (k === 'product') { return s.product ? (s.product === 'gate' ? 'Gate' : 'Fence run') : null; }
    if (k === 'gate') { return gateObj() ? gateObj().label : null; }
    if (k === 'opcion') { return s.opcion || null; }
    if (k === 'mat') { return m() ? m().name : null; }
    return s[k] || null;
  }
  function completo() { return steps().every(function (st) { return value(st.key); }); }
  /* Alturas disponibles: las del perfil si las acota (ranch rail solo 4'), si
     no las del material. */
  function alturas() {
    var st = styleObj();
    return (st && st.heights) || (m() ? m().heights : []);
  }

  function sheetKey() {
    if (!m()) { return null; }
    if (s.product === 'gate' && s.mat === 'chain-link' && s.gate &&
        SHEETS['chainlink-gate-' + s.gate]) { return 'chainlink-gate-' + s.gate; }
    var st = styleObj();
    if (s.mat !== 'aluminum' || !st || !st.slug || !s.height) { return null; }
    var n = s.height.replace("'", '');
    /* Se prueban los dos grados: la residencial primero, que es la habitual. */
    /* Sin paso de ancho, se prueban las medidas que existen y se ofrece la
       primera que tenga plano. El ancho del porton lo confirma el rep, que es
       lo que pasa igualmente: depende de la abertura real. */
    var grados = ['res', 'com'];
    for (var i = 0; i < grados.length; i++) {
      if (s.product === 'gate') {
        var anchos = ['4', '5'];
        for (var j = 0; j < anchos.length; j++) {
          var kg = 'alum-' + n + 'x' + anchos[j] + '-' + grados[i] + '-' + st.slug + '-gate';
          if (SHEETS[kg]) { return kg; }
        }
      } else {
        var kp = 'alum-' + n + 'ft-' + grados[i] + '-' + st.slug + '-panel';
        if (SHEETS[kp]) { return kp; }
      }
    }
    return null;
  }


  function imgSrc() {
    var st = styleObj();

    /* En una pagina de porton manda la foto de porton. Antes se caia al panel
       del material y salia una cerca de vinilo en la ficha de "Double Swing
       Gate", que es justo lo que el cliente NO esta comprando. */
    if (s.product === 'gate') {
      /* La foto de la opcion elegida, que es la misma que enseña su tarjeta:
         al pulsarla, arriba aparece exactamente eso. */
      var o = opciones().filter(function (x) { return x.name === s.opcion; })[0];
      if (o && o.img) {
        /* Misma foto, repintada al color elegido, si esa variante existe. */
        var slug = COLOR_SLUG[s.color] || (s.mat === 'ecfence' && s.style ? s.style.toLowerCase() : null);
        var base = o.img.split('/').pop().replace(/\.(jpg|jpeg|png|webp)$/i, '');
        if (slug && TINTADO_PORTON[base + '-' + slug]) {
          return 'https://crpozo.github.io/wfs-design-preview/assets/gates/tinted/' + base + '-' + slug + '.jpg';
        }
        return o.img;
      }
      var fp = fotoPorton(s.mat, s.gate, s.color || s.style);
      if (fp) { return fp; }
      if (gateObj()) { return gateObj().img; }
    }

    if (st && s.color) {
      /* Tan en vinilo es el color del propio dibujo, asi que no hay variante. */
      var slug = COLOR_SLUG[s.color];
      if (slug && TINTED[st.img + '-' + slug]) {
        return 'https://crpozo.github.io/wfs-design-preview/assets/profiles/tinted/' + st.img + '-' + slug + '.jpg';
      }
    }
    if (st) { return 'https://crpozo.github.io/wfs-design-preview/assets/profiles/' + st.img + '.jpg'; }
    /* Con material elegido pero sin perfil, se enseña ese material. Antes caia
       a la foto del tipo de porton, que es la misma para todos: al cambiar de
       vinilo a chain link la imagen no se movia. */
    if (m()) { return 'https://crpozo.github.io/wfs-design-preview/assets/profiles/' + m().styles[0].img + '.jpg'; }
    return 'https://crpozo.github.io/wfs-design-preview/assets/profiles/aluminum-2-rail-smooth.jpg';
  }

  /** Las filas del resumen. Las usan el panel y la cabecera de la vista 3D. */
  function ficha() {
    var filas = [];
    if (s.product) { filas.push(['Building', value('product')]); }
    if (s.product === 'gate') { filas.push(['Gate type', value('gate')]); }
    if (soloTipo()) { filas.push(['Height', s.height]); return filas; }
    if (s.product === 'gate' && opciones().length) { filas.push(['Gate option', value('opcion')]); }
    if (s.product !== 'gate') { filas.push(['Material', value('mat')]); }
    if (m()) {
      if (s.product !== 'gate' || (!(m().colors && m().colors.length) && !estiloDeOpcion())) {
        filas.push([m().styleLabel, s.style]);
      }
      if (s.product !== 'gate' && m().rails) { filas.push(['Rails', s.rails]); }
      filas.push(['Height', s.height]);
      if (m().colors.length) { filas.push(['Color', s.color]); }
    }
    return filas;
  }

  /**
   * Lo que falta por elegir para poder montar la escena.
   *
   * La vista 3D tiene que enseñar EXACTAMENTE lo que hay en el resumen. Antes
   * rellenaba lo que faltaba con la primera opcion del material, y eso llevaba
   * a que el panel dijera "Color: not chosen yet" mientras la casa salia con
   * una cerca negra que nadie habia pedido.
   */
  function faltan() {
    var out = [];
    if (!s.product) { out.push('what you are building'); }
    if (s.product === 'gate' && !s.gate) { out.push('a gate type'); return out; }
    if (soloTipo()) { if (!s.height) { out.push('a height'); } return out; }
    if (s.product === 'gate' && opciones().length && !s.opcion) { out.push('a gate option'); }
    var mm = m();
    if (!mm) { out.push(s.product === 'gate' ? 'a gate option' : 'a material'); return out; }
    if (!s.style && (s.product !== 'gate' || (!(mm.colors && mm.colors.length) && !estiloDeOpcion()))) {
      out.push('a ' + String(mm.styleLabel).toLowerCase());
    }
    if (s.product !== 'gate' && mm.rails && !s.rails) { out.push('a rail count'); }
    if (!s.height) { out.push('a height'); }
    /* En chain link y EC Fence el acabado ES el paso de estilo, y colors va
       vacio: ahi no hay nada mas que pedir. */
    if (mm.colors.length && !s.color) { out.push('a color'); }
    return out;
  }

  function enumerar(lista) {
    if (lista.length === 1) { return lista[0]; }
    return lista.slice(0, -1).join(', ') + ' and ' + lista[lista.length - 1];
  }

  /** Lo que la escena 3D necesita saber. Null mientras falte algo. */
  function estado3D() {
    if (faltan().length) { return null; }
    var mm = m();
    var col = null;
    if (mm.colors.length) {
      var elegido = mm.colors.filter(function (c) { return c.label === s.color; })[0];
      col = elegido ? elegido.hex : null;
    }
    return {
      mat: s.mat, estilo: s.style, alto: s.height, colorHex: col,
      producto: s.product, gate: s.gate, ancho: s.ancho, marco: s.marco,
      rieles: s.rails ? parseInt(s.rails, 10) : null,
      etiqueta: mm.tag,
      titulo: mm.name + (s.product === 'gate' ? ' gate' : ' fence'),
      resumen: ficha().filter(function (f) { return f[1]; })
    };
  }

  /* 5 pies 9: la estatura media de un adulto en EE.UU. Cambiarla desajusta la
     lectura de todas las alturas. */
  var PERSONA_FT = 5.75;

  /**
   * Referencia de altura EN PROPORCION con el producto de la foto.
   *
   * No es un diagrama aparte: la silueta se planta sobre la foto y se escala
   * contra el producto. Con una cerca de 6 pies, la persona de 5'9" queda un
   * pelin mas baja que el panel; con una de 4, el panel le llega por el pecho.
   * El producto de un recorte llena practicamente el alto del dibujo, asi que
   * su altura en pantalla se toma como ese alto con un pequeño margen: es un
   * "mas o menos" honesto, no una medicion.
   */
  function pintarEscala() {
    var caja = $('escala');
    if (!caja) { return; }
    var ft = parseFloat(s.height);
    if (!s.height || !isFinite(ft) || ft <= 0) {
      caja.classList.remove('is-on');
      var md = $('img') && $('img').parentNode;
      if (md) { md.style.transform = ''; }
      return;
    }
    var img = $('img');
    var marco = img.closest('.bld__frame');
    var mh = marco.clientHeight;
    if (!mh) { return; }

    /* Alto en pantalla del contenido de la imagen, segun su object-fit. */
    var cs = getComputedStyle(img);
    var innerW = img.clientWidth - ((parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0));
    var innerH = img.clientHeight - ((parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0));
    var contentH = innerH;
    if (img.naturalWidth && img.naturalHeight) {
      var k = cs.objectFit === 'cover'
        ? Math.max(innerW / img.naturalWidth, innerH / img.naturalHeight)
        : Math.min(innerW / img.naturalWidth, innerH / img.naturalHeight);
      contentH = Math.min(innerH, img.naturalHeight * k);
    }

    /* Tres piezas que tienen que contar la misma historia:
         - la PERSONA va fija: es lo unico que el visitante sabe constante;
         - la COTA naranja mide la altura elegida a la escala de la persona;
         - y la FOTO se escala para que el producto mida lo que dice la cota.
       Sin lo tercero, la linea decia "4 pies" mientras la valla de la foto
       seguia enorme al lado: la cota y la imagen se contradecian, y la gracia
       es precisamente ver que tan grande o pequeña queda la cerca. Escalar la
       foto entera no deforma el producto: solo lo acerca o lo aleja. */
    var margenes = medirMargenes(img);
    if (!margenes) {
      /* Sin lectura de pixeles (canvas tainted en produccion) no sabemos el
         color del fondo, asi que la foto no se escala: mejor quieta que con
         un recuadro visible alrededor. */
      margenes = cs.objectFit === 'cover'
        ? { inf: 0.02, sup: 0.02, fondo: null }
        : { inf: 0.10, sup: 0.06, fondo: null };
    }
    var base = Math.round((mh - contentH) / 2 + contentH * margenes.inf);
    var usable = mh - base - 10;
    var maxFt = 8;
    if (m() && alturas().length) {
      maxFt = Math.max.apply(null, alturas().map(function (x) { return parseFloat(x) || 0; })) || 8;
    }
    /* La persona sale del alto del MARCO, no de la imagen: si dependiera de la
       imagen, cambiaria de tamaño al cambiar de perfil. */
    var personaPx = Math.min(mh * 0.42, usable * (PERSONA_FT / maxFt) * 0.98);
    personaPx = Math.max(40, personaPx);
    var cotaPx = personaPx * (ft / PERSONA_FT);

    /* Escala de la foto: el producto dibujado pasa a medir cotaPx. El pivote
       es su base, que asi no se mueve del suelo.
       SOLO se escala si el fondo de la foto es liso: entonces el marco se
       pinta de ese mismo color, la costura desaparece y lo unico que se ve
       cambiar de tamaño es el objeto. Si el fondo es una escena real (cesped,
       cielo), encoger la foto dejaba un recuadro flotando dentro del marco,
       asi que ahi la proporcion la cuentan solo la cota y la persona. */
    var media = img.parentNode;
    if (margenes.fondo) {
      marco.style.background = 'rgb(' + margenes.fondo.join(',') + ')';
      var productoPx = contentH * Math.max(0.15, 1 - margenes.inf - margenes.sup);
      var k = Math.max(0.2, Math.min(1.12, cotaPx / productoPx));
      media.style.transformOrigin = '50% ' + (mh - base) + 'px';
      media.style.transform = 'scale(' + k.toFixed(4) + ')';
    } else {
      media.style.transform = '';
    }

    /* La cota vertical mide el PRODUCTO y lleva su medida en el chip, centrado
       en la linea como en un plano; la persona va al lado sin numero, que es la
       referencia y no lo que se mide. La linea de suelo las une para que se
       lea que estan sobre la misma base. */
    caja.innerHTML =
      '<span class="sc-cota"><span class="sc-tag">' + esc(s.height) + '</span></span>' +
      '<svg viewBox="-4 -1 30 101" aria-hidden="true" style="height:' + Math.round(personaPx) + 'px">' +
        '<g class="sc-person">' +
          '<circle cx="11" cy="10" r="10"/>' +
          '<path d="M11 23c-8 0-13 5-13 13v26h6l1 38h5l1-38h1l1 38h5l1-38h6V36c0-8-5-13-13-13z"/>' +
        '</g>' +
      '</svg>';
    /* El contenedor es la cota: crece con la altura elegida. */
    caja.style.height = Math.round(cotaPx) + 'px';
    caja.style.bottom = base + 'px';
    caja.setAttribute('aria-label', s.height + ' product next to a 5 foot 9 person');
    caja.classList.add('is-on');
  }

  function pintarVista() {
    var img = $('img'), src = imgSrc();
    var marco = img.closest('.bld__frame');
    var esTinte = src.indexOf('/tinted/') !== -1;
    /* Los perfiles son recortes sobre blanco y piden aire alrededor; las fotos
       de porton son fotografias y quedan mejor llenando el marco. */
    var esFoto = src.indexOf('/profiles/') === -1;
    marco.classList.toggle('is-foto', esFoto);
    marco.style.background = esFoto ? FONDO_FOTO
      : (!esTinte ? FONDO_ORIGINAL
        : (src.indexOf('-white.jpg') !== -1 ? FONDO_BLANCO : FONDO_TINTE));
    if (img.getAttribute('src') !== src) {
      img.classList.add('is-swapping');
      /* crossorigin: en produccion las imagenes vienen de GitHub Pages (otro
         dominio, que si manda Access-Control-Allow-Origin: *). Sin esto el
         canvas queda "tainted", no se puede medir el producto y la foto no se
         escala a la altura elegida: la cota decia 6' y la cerca seguia enorme. */
      var n = new Image();
      n.crossOrigin = 'anonymous';
      n.onload = function () {
        /* Una foto vertical recortada a 4:3 pierde media hoja, asi que esa se
           encaja entera en vez de llenar. */
        marco.classList.toggle('is-vertical', esFoto && n.naturalWidth / n.naturalHeight < 1.15);
        img.src = src;
        img.classList.remove('is-swapping');
      };
      n.onerror = function () { img.classList.remove('is-swapping'); };
      n.src = src;
    }
    /* La etiqueta dice QUE es lo que se ve. En un porton eso no es el material:
       el material dejo de ser un paso y ahora viaja dentro de la opcion, asi
       que poner "Vinyl / PVC" encima de la foto era enseñar un dato interno.
       Se pone la opcion elegida, o el tipo de porton mientras no la haya. */
    var etiqueta;
    if (s.product === 'gate') {
      etiqueta = s.opcion || (gateObj() ? gateObj().label : 'Start here');
    } else {
      etiqueta = m() ? m().name : 'Start here';
    }
    $('badge').textContent = etiqueta;

    /* El boton se enciende cuando la configuracion esta completa, y mientras
       tanto dice que falta. Encenderlo antes obligaba a inventar las opciones
       sin elegir, y la casa acababa enseñando otra cerca. */
    var b3d = root.querySelector('.bld__3d');
    if (b3d) {
      var falta = faltan();
      b3d.disabled = falta.length > 0;
      b3d.title = falta.length ? 'Pick ' + enumerar(falta) + ' first' : '';
      var pie = root.querySelector('.bld__3d-pie');
      if (pie) {
        pie.textContent = falta.length
          ? 'Pick ' + enumerar(falta) + ' to see it in 3D.'
          : 'See it on a real home, with the yard around it.';
      }
    }

    var filas = ficha();
    root.querySelector('.bld__spec dl').innerHTML = filas.map(function (f) {
      var sw = '';
      if (f[0] === 'Color' && f[1] && m()) {
        var c = m().colors.filter(function (x) { return x.label === f[1]; })[0];
        if (c) { sw = '<i class="sw" style="background:' + c.hex + '"></i>'; }
      }
      return '<dt>' + esc(f[0]) + '</dt><dd' + (f[1] ? '' : ' class="is-empty"') + '>' +
             sw + esc(f[1] || 'Not chosen yet') + '</dd>';
    }).join('');

    /* Al final, no al principio: la escala pinta el marco del color del fondo
       de la foto y tiene que pisar el que esta funcion acaba de poner. */
    pintarEscala();
  }

  function opt(set, v, nombre, sub, img) {
    return '<button class="opt" data-set="' + set + '" data-v="' + esc(v) + '" aria-pressed="' + (s[set === 'mat' ? 'mat' : set] === v) + '">' +
      (img ? '<img class="opt__thumb" src="' + img + '" alt="" loading="lazy">' : '') +
      '<span><span class="opt__name">' + esc(nombre) + '</span>' +
      (sub ? '<span class="opt__sub">' + esc(sub) + '</span>' : '') + '</span>' +
      '<span class="opt__tick"></span></button>';
  }

  function cuerpo(k) {
    if (k === 'product') {
      return opt('product', 'fence', 'Fence run', 'Panels, posts and rails for a run', 'https://crpozo.github.io/wfs-design-preview/assets/profiles/aluminum-3-rail-rake.jpg') +
             opt('product', 'gate',  'Gate',      'Single, double, sliding, cantilever or rolling', 'https://crpozo.github.io/wfs-design-preview/assets/gate-double.jpg');
    }
    if (k === 'gate') {
      return GATES.map(function (g) { return opt('gate', g.id, g.label, g.sub, g.img); }).join('');
    }
    if (k === 'opcion') {
      return opciones().map(function (o) {
        return opt('opcion', o.name, o.name, o.notes, o.img);
      }).join('');
    }
    if (k === 'mat') {
      return matsPermitidos().map(function (id) {
        var x = MAT[id];
        /* Recorte de producto, tambien en portones. Se probo con las fotos de
           porton y a 62x46 no se leen: la de aluminio pasa por un camino, la de
           chain link por unas escaleras, y DuraFence y EC Fence comparten foto,
           o sea dos opciones identicas. Aqui lo que hay que distinguir es el
           MATERIAL, y para eso el recorte gana. La foto de porton manda donde
           importa, que es la vista grande. */
        return opt('mat', id, x.name, x.tag, 'https://crpozo.github.io/wfs-design-preview/assets/profiles/' + x.styles[0].img + '.jpg');
      }).join('');
    }
    if (k === 'style') {
      return m().styles.map(function (x) {
        return opt('style', x.label, x.label, x.sub, 'https://crpozo.github.io/wfs-design-preview/assets/profiles/' + x.img + '.jpg');
      }).join('');
    }
    if (k === 'rails') {
      return '<div class="opts-row">' + m().rails.map(function (r) {
        return '<button class="chip" data-set="rails" data-v="' + esc(r) + '" aria-pressed="' + (s.rails === r) + '">' + esc(r) + '</button>';
      }).join('') + '</div>';
    }
    if (k === 'height') {
      var lista = alturas();
      return '<div class="opts-row">' + lista.map(function (h) {
        return '<button class="chip" data-set="' + k + '" data-v="' + esc(h) + '" aria-pressed="' + (s[k] === h) + '">' + esc(h) + '</button>';
      }).join('') + '</div>';
    }
    if (k === 'color') {
      return '<div class="opts-row">' + m().colors.map(function (c) {
        return '<button class="chip chip--color" data-set="color" data-v="' + esc(c.label) + '" aria-pressed="' + (s.color === c.label) + '">' +
          '<i class="sw" style="background:' + c.hex + '"></i>' + esc(c.label) + '</button>';
      }).join('') + '</div>';
    }
    return '';
  }

  function pintarPasos() {
    var lista = steps();
    /* Ningun paso se cierra al contestarlo. Elegir abre el siguiente, y el que
       acabas de tocar sigue desplegado para poder comparar: mirar el aluminio,
       volver al vinilo, probar otra altura. Plegarlos obligaba a pulsar
       "Change" para cada comparacion, que es justo lo que uno hace al elegir.
       Lo unico que sigue cerrado es lo que aun no toca, para que se vea que
       hay un orden. */
    var html = lista.map(function (st, i) {
      var val = value(st.key);
      var bloqueado = i > 0 && !value(lista[i - 1].key);
      var plegado = st.key === PLEGABLE && val && !reabierto[st.key];
      var abierto = !bloqueado && !plegado;
      var cls = 'step' + (abierto ? ' is-open' : '') + (bloqueado ? ' is-locked' : '');
      var h = '<section class="' + cls + '" data-i="' + i + '">' +
        '<div class="step__head"' + (plegado ? ' data-edit="' + esc(st.key) + '"' : '') + '>' +
          '<span class="step__n">' + ('0' + (i + 1)) + '</span>' +
          '<span class="step__t">' + esc(st.title) + '</span>' +
          /* El valor elegido se enseña tambien con el paso abierto: asi el
             resumen esta a mano sin bajar al panel de la derecha. */
          (val ? '<span class="step__val">' + esc(val) + '</span>' : '') +
          (plegado ? '<button class="step__edit" type="button" data-edit="' + esc(st.key) + '">Change</button>' : '') +
        '</div>';
      if (abierto) { h += '<div class="step__body">' + cuerpo(st.key) + '</div>'; }
      return h + '</section>';
    }).join('');

    if (completo()) {
      var k = sheetKey();
      var titulo = [m().name, s.style, s.height, s.color]
        .filter(Boolean).join(' · ');
      html += '<div class="bld__done">' +
        '<span class="wfs-kicker">Your build</span>' +
        '<h2>' + esc((s.product === 'gate' ? gateObj().label + ' gate · ' : '') + titulo) + '</h2>' +
        '<p>Send it over with your linear footage and we come back with pricing in 24 hours.</p>' +
        '<div class="bld__actions">' +
          '<a class="btn btn-primary" href="estimate.html">Request a Quote</a>' +
          '<a class="btn btn-ghost on-dark" href="specs.html">Browse all spec sheets</a>' +
        '</div>' +
        '<div class="bld__sheet">' + (k ?
          'Spec sheet for this build: <a href="https://crpozo.github.io/wfs-design-preview/assets/specs/' + k + '.pdf" download>' + esc(k) + '.pdf</a>' :
          '<span class="none">No spec sheet drawn for this exact build yet. Ask us and we will send the closest one.</span>') +
        '</div></div>';
    }
    $('steps').innerHTML = html;
  }

  function render() { pintarPasos(); pintarVista(); }

  root.addEventListener('click', function (e) {
    var v3d = e.target.closest('.bld__3d');
    if (v3d) {
      var est = estado3D();
      if (!est) { return; }
      v3d.classList.add('is-cargando');
      cargar3D().then(function () {
        v3d.classList.remove('is-cargando');
        window.WFS3D.abrir(est);
      }, function () {
        v3d.classList.remove('is-cargando');
        v3d.classList.add('is-error');
        v3d.lastChild.textContent = '3D view unavailable';
      });
      return;
    }
    var edit = e.target.closest('[data-edit]');
    if (edit) { reabierto[edit.dataset.edit] = true; return render(); }
    var b = e.target.closest('[data-set]');
    if (!b) { return; }
    var campo = b.dataset.set, v = b.dataset.v;

    /* Cambiar algo de arriba invalida lo de abajo: un perfil de vinilo no
       existe en chain link, y un ancho de porton no aplica a una cerca. */
    if (campo === 'product' && s.product !== v) {
      s.product = v; s.gate = null; s.opcion = null; s.mat = null; s.style = null;
      s.rails = null; s.height = null; s.color = null; s.grade = null;
    } else if (campo === 'gate' && s.gate !== v) {
      /* Cambiar de tipo de porton cambia lo que ese porton ofrece: las
         tarjetas son otras y puede que el material elegido ya no se venda
         (un corredero no lleva aluminio). Se conserva lo que siga valiendo. */
      s.gate = v;
      s.opcion = null; s.ancho = null; s.marco = null;
      s.mat = null; s.style = null; s.rails = null; s.height = null; s.color = null; s.grade = null;
      /* Sin tarjetas (cantilever, rolling) no hay de donde sacar el material,
         asi que se pone el que esa pagina da por defecto. */
      if (!opciones().length || soloTipo()) {
        s.mat = cfg().matDefecto || 'chain-link';
        s.style = MAT[s.mat] ? MAT[s.mat].styles[0].label : null;
      }
    } else if (campo === 'opcion' && s.opcion !== v) {
      /* La opcion trae su material y su perfil: es lo que enseña su foto en la
         pagina. Si cambian, lo de abajo deja de valer. */
      var o = opciones().filter(function (x) { return x.name === v; })[0] || {};
      var cambiaMat = o.mat && o.mat !== s.mat;
      s.opcion = v;
      s.ancho = o.ancho || null;
      s.marco = o.marco || null;
      if (cambiaMat) { s.mat = o.mat; s.height = null; s.color = null; }
      s.style = o.estilo || (MAT[s.mat] ? MAT[s.mat].styles[0].label : null);
    } else if (campo === 'mat' && s.mat !== v) {
      s.mat = v; s.style = null; s.rails = null; s.height = null; s.color = null; s.grade = null;
    } else { s[campo] = v; }
    if (campo === 'style' && s.height && alturas().indexOf(s.height) === -1) { s.height = null; }

    render();
  });

  /* La proporcion depende de la imagen ya cargada y del tamaño en pantalla:
     se recalcula al terminar cada carga y al redimensionar. */
  $('img').addEventListener('load', pintarEscala);
  window.addEventListener('resize', pintarEscala, { passive: true });

  render();

  /* API para que las tarjetas de la pagina elijan un perfil sin recargar. */
  return {
    elegirPorImagen: function (img) {
      if (!m()) { return false; }
      var enc = m().styles.filter(function (x) { return x.img === img; })[0];
      if (!enc) { return false; }
      s.style = enc.label;
      render();
      return true;
    }
  };
  }

  /* Montaje. En la pagina suelta del configurador se llama sin fijar nada. */
  /**
   * Cuanto ocupa la cabecera fija, en una variable CSS.
   *
   * El panel derecho se queda pegado al hacer scroll, pero a 24px del borde:
   * la cabecera del sitio es sticky y mide 132px, asi que le tapaba 108px y
   * la foto salia cortada por arriba. La altura no es fija (cambia entre
   * escritorio y movil), asi que se mide.
   */
  function medirCabecera() {
    var alto = 0;
    var cabs = document.querySelectorAll('header');
    for (var i = 0; i < cabs.length; i++) {
      var c = getComputedStyle(cabs[i]);
      if (c.position !== 'sticky' && c.position !== 'fixed') { continue; }
      var r = cabs[i].getBoundingClientRect();
      if (r.top <= 2 && r.width > window.innerWidth * 0.5) { alto = Math.max(alto, r.height); }
    }
    document.documentElement.style.setProperty('--wfs-cabecera', Math.round(alto) + 'px');
  }

  window.WFSBuilder = {
    instancias: [],
    mount: function (root, opts) {
      if (!root) { return null; }
      medirCabecera();
      if (!this._obsCab) {
        this._obsCab = true;
        window.addEventListener('resize', medirCabecera, { passive: true });
      }
      var api = crear(root, opts);
      this.instancias.push({ root: root, api: api });
      return api;
    },
    /* Las tarjetas de perfil llaman aqui: eligen la variante y llevan la vista
       al configurador, en vez de navegar a otra pagina. */
    elegir: function (img) {
      var hecho = false;
      this.instancias.forEach(function (i) { if (i.api.elegirPorImagen(img)) { hecho = true; } });
      if (hecho) { this.ir(); }
      return hecho;
    },
    /* Las tarjetas que no corresponden a una variante del configurador (por
       ejemplo las de porton, que son fotos de proyecto) solo llevan la vista
       al configurador ya embebido, sin cambiar de pagina. */
    ir: function () {
      if (!this.instancias.length) { return false; }
      var raiz = this.instancias[0].root;
      /* Animacion propia en vez de behavior:'smooth': el configurador reescribe
         su DOM en este mismo tick y el anclaje de scroll cancela el suave
         nativo. Con la pestaña en segundo plano rAF se congela, asi que un
         temporizador toma el relevo y el salto se hace igual. */
      var hecho = false;
      var arrancar = function () {
        if (hecho) { return; }
        hecho = true;
        var destino = raiz.getBoundingClientRect().top + window.pageYOffset - 24;
        var tope = document.documentElement.scrollHeight - window.innerHeight;
        destino = Math.max(0, Math.min(destino, tope));
        var quieto = document.hidden ||
          (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
        if (quieto) { window.scrollTo(0, destino); return; }
        var desde = window.pageYOffset, dur = 520, t0 = null;
        (function paso(ahora) {
          if (t0 === null) { t0 = ahora; }
          var k = Math.min(1, (ahora - t0) / dur);
          var e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
          window.scrollTo(0, desde + (destino - desde) * e);
          if (k < 1) { requestAnimationFrame(paso); }
        })(performance.now());
      };
      requestAnimationFrame(arrancar);
      setTimeout(arrancar, 120);
      return true;
    }
  };
})();
