(function(){const App=()=>React.createElement(React.Fragment,null,React.createElement(SiteHeader,{active:"Fence Education Hub"}),React.createElement(FaqHero,null),React.createElement(FaqTopics,null),React.createElement(FaqCTA,null),React.createElement(Footer,null));ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(App,null));

;Object.assign(window,{App:typeof App!=="undefined"?App:window.App});
})();