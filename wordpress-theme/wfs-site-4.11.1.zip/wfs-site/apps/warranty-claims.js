(function(){ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(WarrantyClaimsPage,null));


})();