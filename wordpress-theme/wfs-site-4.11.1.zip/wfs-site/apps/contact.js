(function(){const App=()=>React.createElement(React.Fragment,null,React.createElement(SiteHeader,{active:"Company"}),React.createElement(ContactHero,null),React.createElement(FinalCTA,null),React.createElement(Footer,null));ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(App,null));

;Object.assign(window,{App:typeof App!=="undefined"?App:window.App});
})();