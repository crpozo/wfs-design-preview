const ProductsHero = () => {
  const t = useT();
  return /* @__PURE__ */ React.createElement(
    PageHero,
    {
      crumbs: [[t("Home", "Inicio"), "Homepage.html"], [t("Products", "Productos"), null]],
      eyebrow: t("Full catalog", "Cat\xE1logo completo"),
      title: t("Five fence systems.", "Cinco sistemas de cerca."),
      accent: t("Two convenient locations.", "Dos ubicaciones convenientes."),
      accentBreak: true,
      subtitle: t("Factory-direct material, vinyl, aluminum, chain link, metal and EC Fence, plus gates, hardware and accessories. Same supplier-direct pricing for contractors, homeowners and DIY projects.", "Material directo de f\xE1brica, vinilo, aluminio, malla cicl\xF3nica, metal y EC Fence, m\xE1s portones, herrajes y accesorios. El mismo precio directo de proveedor para contratistas, propietarios y proyectos de bricolaje."),
      image: "https://crpozo.github.io/wfs-design-preview/assets/PVC.png",
      actions: [{
        primary: true,
        href: "https://crpozo.github.io/wfs-design-preview/assets/wfs-catalog.pdf",
        download: "WFS-Fence-Catalog.pdf",
        label: /* @__PURE__ */ React.createElement("span", { style: { display: "inline-flex", alignItems: "center", gap: 10 } }, t("Download Catalog (PDF)", "Descargar cat\xE1logo (PDF)"), /* @__PURE__ */ React.createElement("svg", { width: "14", height: "14", viewBox: "0 0 16 16", fill: "none", "aria-hidden": "true" }, /* @__PURE__ */ React.createElement("path", { d: "M8 2 V13 M4 9 L8 13 L12 9", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "square" })))
      }]
    }
  );
};
const PRODUCT_INTRO_STATS = [
  ["5", { EN: "Fence systems", ES: "Sistemas de cerca" }],
  ["5", { EN: "Gate systems", ES: "Sistemas de port\xF3n" }],
  ["2", { EN: "Yards \xB7 FM + PC", ES: "Sucursales \xB7 FM + PC" }],
  [{ EN: "Lifetime", ES: "De por vida" }, { EN: "Warranty", ES: "Garant\xEDa" }]
];
const ProductsIntro = () => {
  const t = useT();
  return /* @__PURE__ */ React.createElement("section", { style: { background: "var(--white)", padding: "120px 0" } }, /* @__PURE__ */ React.createElement("div", { className: "container" }, /* @__PURE__ */ React.createElement("div", { style: {
    display: "grid",
    gridTemplateColumns: "1.4fr 1fr",
    columnGap: 64,
    rowGap: 28,
    alignItems: "end"
  } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h2", { className: "display", style: { margin: 0, fontSize: "clamp(26px, 2.6vw, 36px)", lineHeight: 1.12, letterSpacing: "-0.02em" } }, t("Everything you need to build the perimeter,", "Todo lo que necesitas para construir el per\xEDmetro,"), /* @__PURE__ */ React.createElement("br", null), /* @__PURE__ */ React.createElement("span", { style: { color: "var(--tangerine)" } }, t("and nothing we wouldn't put on our own job.", "y nada que no pondr\xEDamos en nuestro propio trabajo.")))), /* @__PURE__ */ React.createElement("p", { style: { margin: 0, fontSize: 16, lineHeight: 1.7, color: "var(--charcoal)", maxWidth: 420 } }, t("We curate every SKU we carry. If a manufacturer can't meet our spec, it doesn't make it onto the floor. Browse by material below, or jump straight to gates and hardware.", "Seleccionamos cada SKU que manejamos. Si un fabricante no cumple con nuestra especificaci\xF3n, no llega al piso de venta. Explora por material abajo, o ve directo a portones y herrajes."))), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 64 } }, /* @__PURE__ */ React.createElement(StatStrip, { items: PRODUCT_INTRO_STATS.map(([n, l]) => [t(n), t(l)]) }))));
};
const ProductHardware = () => {
  const t = useT();
  return /* @__PURE__ */ React.createElement("section", { style: { background: "var(--white)", padding: "120px 0" } }, /* @__PURE__ */ React.createElement("div", { className: "container" }, /* @__PURE__ */ React.createElement(
    PageSectionHeader,
    {
      number: "03",
      label: t("Hardware & accessories", "Herrajes y accesorios"),
      title: t("Posts, hinges, latches,", "Postes, bisagras, pestillos,"),
      accent: t("and the little stuff that breaks first.", "y las piezas peque\xF1as que fallan primero."),
      sub: t("If we sell the panel, we stock the matching hardware. Stainless-steel kits on every gate, drop rods on every double-swing.", "Si vendemos el panel, tenemos en existencia los herrajes que combinan. Kits de acero inoxidable en cada port\xF3n, varillas de anclaje en cada port\xF3n doble."),
      link: [t("Request hardware list", "Solicitar lista de herrajes"), "estimate.html"]
    }
  ), /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 } }, [
    [t("Posts & rails", "Postes y rieles"), t("Posts for every material, in a range of colors, end, corner and line posts (EP/CP/LP) for aluminum and PVC, chain-link posts by diameter and gauge, and a single profile for metal.", "Postes para cada material, en varios colores: postes de extremo, esquina y l\xEDnea (EP/CP/LP) para aluminio y PVC, postes de chain link seg\xFAn di\xE1metro y calibre, y un solo perfil para metal.")],
    [t("Hinges & latches", "Bisagras y pestillos"), t("Stainless hinges, drop rods, magnetic latches, padlockable kits.", "Bisagras de acero inoxidable, varillas de anclaje, pestillos magn\xE9ticos, kits con candado.")],
    [t("Caps & fittings", "Tapas y accesorios"), t("Post caps, tension bands and brace bands, plus the chain-link fittings that finish a run.", "Tapas de poste, bandas de tensi\xF3n y de refuerzo, m\xE1s los accesorios de chain link que rematan el tramo.")],
    [t("Gate automation", "Automatizaci\xF3n"), t("We don't build automated gates. The most we do is weld on a mounting plate so you can add your own operator, sourcing and setting up the automation is on you.", "No fabricamos portones autom\xE1ticos. Lo m\xE1ximo que hacemos es soldar un plato de montaje para que instales tu propio operador; conseguir y configurar la automatizaci\xF3n corre por tu cuenta.")]
  ].map(([title, body]) => /* @__PURE__ */ React.createElement("article", { key: title, style: {
    background: "var(--white)",
    padding: "24px 22px",
    border: "1px solid rgba(0,16,17,0.1)"
  } }, /* @__PURE__ */ React.createElement("div", { className: "mono", style: {
    fontSize: 13.5,
    letterSpacing: "0.22em",
    textTransform: "uppercase",
    color: "var(--tangerine)",
    fontWeight: 700,
    marginBottom: 10
  } }, t("Hardware", "Herrajes")), /* @__PURE__ */ React.createElement("h3", { className: "display", style: { margin: "0 0 10px", fontSize: 21.5, lineHeight: 1.1 } }, title), /* @__PURE__ */ React.createElement("p", { style: { margin: 0, fontSize: 15, lineHeight: 1.55, color: "var(--charcoal)" } }, body))))));
};
const ProductsCTA = () => {
  const t = useT();
  return /* @__PURE__ */ React.createElement(
    CTABand,
    {
      kicker: t("Spec your run", "Especifica tu tramo"),
      title: t("Send your dimensions", "Env\xEDa tus dimensiones"),
      accent: t("we'll come back with stock + price.", "te respondemos con existencias y precio."),
      body: t("Linear feet, height, color, gate count. We'll quote it in 24 hours with delivery and pickup options for both yards.", "Pies lineales, altura, color, n\xFAmero de portones. Lo cotizamos en 24 horas con opciones de entrega y retiro para ambas sucursales."),
      primary: [t("Request a quote", "Solicitar cotizaci\xF3n"), "estimate.html"],
      secondary: [t("Talk to a rep", "Habla con un representante"), "tel:2396895496"]
    }
  );
};
Object.assign(window, { ProductsHero, ProductsIntro, ProductHardware, ProductsCTA });
