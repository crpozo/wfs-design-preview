const Breadcrumb = ({ items, light = true }) => /* @__PURE__ */ React.createElement("nav", { className: "mono", style: {
  fontSize: 13.5,
  letterSpacing: "0.18em",
  textTransform: "uppercase",
  color: light ? "rgba(255,255,255,0.6)" : "var(--charcoal)",
  marginBottom: 24,
  display: "flex",
  gap: 10,
  flexWrap: "wrap",
  alignItems: "center"
} }, items.map(([label, href], i) => /* @__PURE__ */ React.createElement(React.Fragment, { key: i }, i > 0 && /* @__PURE__ */ React.createElement("span", { "aria-hidden": true }, "\u203A"), href ? /* @__PURE__ */ React.createElement("a", { href, style: { color: "inherit" } }, label) : /* @__PURE__ */ React.createElement("span", { style: { color: light ? "var(--white)" : "var(--ink)" } }, label))));
const PageHero = ({ eyebrow, title, accent, accentBreak, subtitle, image, crumbs, actions, height = "clamp(420px, 58vh, 560px)" }) => /* @__PURE__ */ React.createElement("section", { style: {
  position: "relative",
  color: "var(--white)",
  overflow: "hidden",
  minHeight: height,
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
  background: "#263166"
} }, image && /* @__PURE__ */ React.createElement("img", { src: image, alt: "", "aria-hidden": "true", style: {
  position: "absolute",
  inset: 0,
  width: "100%",
  height: "100%",
  objectFit: "cover",
  objectPosition: "center 45%",
  zIndex: 0
} }), /* @__PURE__ */ React.createElement("div", { "aria-hidden": true, style: {
  position: "absolute",
  inset: 0,
  zIndex: 1,
  background: "linear-gradient(95deg, rgba(38, 49, 103,0.86) 0%, rgba(38, 49, 103,0.68) 38%, rgba(38, 49, 103,0.42) 68%, rgba(38, 49, 103,0.26) 100%)"
} }), /* @__PURE__ */ React.createElement("div", { className: "container", style: {
  position: "relative",
  zIndex: 2,
  width: "100%",
  paddingTop: 72,
  paddingBottom: 56
} }, eyebrow && /* @__PURE__ */ React.createElement("div", { className: "mono", style: {
  display: "inline-flex",
  alignItems: "center",
  gap: 14,
  marginBottom: 22,
  fontSize: "clamp(12px, 1.1vw, 13px)",
  fontWeight: 700,
  letterSpacing: "0.22em",
  textTransform: "uppercase",
  color: "rgba(255,255,255,0.85)"
} }, /* @__PURE__ */ React.createElement("span", { "aria-hidden": true, style: { width: 34, height: 3, background: "var(--tangerine)", borderRadius: 2 } }), eyebrow), /* @__PURE__ */ React.createElement("h1", { style: {
  margin: "0 0 18px",
  fontFamily: "var(--display)",
  fontVariationSettings: "'wdth' 100",
  fontWeight: 800,
  fontSize: "clamp(30px, 3.6vw, 50px)",
  lineHeight: 1.02,
  letterSpacing: "-0.015em",
  textTransform: "uppercase",
  color: "var(--white)",
  textShadow: "0 2px 28px rgba(0,0,0,0.28)",
  maxWidth: 880
} }, title, accent && /* @__PURE__ */ React.createElement(React.Fragment, null, accentBreak ? /* @__PURE__ */ React.createElement("br", null) : " ", /* @__PURE__ */ React.createElement("span", { style: { color: "var(--blue-ice)" } }, accent))), subtitle && /* @__PURE__ */ React.createElement("p", { style: {
  fontSize: 17.5,
  lineHeight: 1.55,
  maxWidth: 600,
  margin: 0,
  color: "rgba(255,255,255,0.85)"
} }, subtitle), actions && actions.length > 0 && /* @__PURE__ */ React.createElement("div", { style: { marginTop: 30, display: "flex", gap: 14, flexWrap: "wrap" } }, actions.map((a, i) => a.primary ? /* @__PURE__ */ React.createElement(
  "a",
  {
    key: i,
    href: a.href,
    download: a.download,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "15px 28px",
      borderRadius: 999,
      background: "var(--tangerine)",
      color: "var(--white)",
      fontFamily: "var(--sans)",
      fontSize: 14.5,
      fontWeight: 700,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      boxShadow: "0 8px 24px rgba(255, 113, 51,0.35)",
      transition: "transform 0.18s, box-shadow 0.18s, background 0.18s"
    },
    onMouseEnter: (e) => {
      e.currentTarget.style.transform = "translateY(-1px)";
      e.currentTarget.style.boxShadow = "0 12px 32px rgba(255, 113, 51,0.45)";
    },
    onMouseLeave: (e) => {
      e.currentTarget.style.transform = "translateY(0)";
      e.currentTarget.style.boxShadow = "0 8px 24px rgba(255, 113, 51,0.35)";
    }
  },
  a.label
) : /* @__PURE__ */ React.createElement(
  "a",
  {
    key: i,
    href: a.href,
    download: a.download,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "15px 28px",
      borderRadius: 999,
      background: "rgba(255,255,255,0.08)",
      color: "var(--white)",
      border: "1.5px solid rgba(255,255,255,0.55)",
      backdropFilter: "blur(6px)",
      fontFamily: "var(--sans)",
      fontSize: 14.5,
      fontWeight: 700,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      transition: "background 0.18s, border-color 0.18s"
    },
    onMouseEnter: (e) => {
      e.currentTarget.style.background = "rgba(255,255,255,0.18)";
      e.currentTarget.style.borderColor = "var(--white)";
    },
    onMouseLeave: (e) => {
      e.currentTarget.style.background = "rgba(255,255,255,0.08)";
      e.currentTarget.style.borderColor = "rgba(255,255,255,0.55)";
    }
  },
  a.label
)))));
const PageSectionHeader = ({ number, label, title, accent, sub, link }) => /* @__PURE__ */ React.createElement("div", { style: {
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: 48,
  alignItems: "end",
  paddingBottom: 24,
  marginBottom: 28,
  borderBottom: "1px solid rgba(0,16,17,0.12)"
} }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h2", { className: "display", style: {
  margin: 0,
  fontSize: "clamp(28px, 3vw, 40px)",
  lineHeight: 1,
  letterSpacing: "-0.02em",
  fontWeight: 800
} }, title, accent && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("br", null), /* @__PURE__ */ React.createElement("span", { style: { color: "var(--tangerine)" } }, accent)))), /* @__PURE__ */ React.createElement("div", { style: {
  display: "flex",
  flexDirection: "column",
  alignItems: "flex-end",
  gap: 18
} }, sub && /* @__PURE__ */ React.createElement("p", { style: {
  margin: 0,
  maxWidth: 380,
  fontSize: 15.5,
  lineHeight: 1.55,
  color: "var(--charcoal)",
  textAlign: "right"
} }, sub), link && /* @__PURE__ */ React.createElement("a", { href: link[1], className: "mono", style: {
  display: "inline-flex",
  alignItems: "center",
  gap: 10,
  fontSize: 14,
  fontWeight: 700,
  letterSpacing: "0.22em",
  textTransform: "uppercase",
  color: "var(--ink)",
  borderBottom: "1px solid var(--ink)",
  paddingBottom: 4
} }, link[0], /* @__PURE__ */ React.createElement("svg", { width: "12", height: "12", viewBox: "0 0 16 16", fill: "none" }, /* @__PURE__ */ React.createElement("path", { d: "M3 8h10m0 0L9 4m4 4l-4 4", stroke: "currentColor", strokeWidth: "1.6", strokeLinecap: "square" })))));
const StatStrip = ({ items, dark = false }) => /* @__PURE__ */ React.createElement("div", { style: {
  display: "grid",
  gridTemplateColumns: `repeat(${items.length}, 1fr)`,
  gap: 28,
  paddingTop: 30,
  borderTop: `1px solid ${dark ? "rgba(255,255,255,0.18)" : "rgba(0,16,17,0.12)"}`
} }, items.map(([n, l]) => /* @__PURE__ */ React.createElement("div", { key: l }, /* @__PURE__ */ React.createElement("div", { className: "display", style: { fontSize: "clamp(28px, 3vw, 40px)", lineHeight: 1, color: dark ? "var(--white)" : "var(--ink)" } }, n), /* @__PURE__ */ React.createElement("div", { className: "mono", style: {
  marginTop: 12,
  fontSize: 13.5,
  letterSpacing: "0.18em",
  textTransform: "uppercase",
  color: dark ? "var(--alice-blue)" : "var(--charcoal)"
} }, l))));
const CTABand = ({ kicker, title, accent, body, primary, secondary, theme = "cream" }) => {
  const bg = theme === "ink" ? "var(--ink)" : theme === "parchment" ? "var(--parchment)" : "#ffffff";
  const fg = theme === "ink" ? "var(--parchment)" : "var(--ink)";
  const sub = theme === "ink" ? "var(--alice-blue)" : "var(--charcoal)";
  return /* @__PURE__ */ React.createElement("section", { style: {
    background: bg,
    color: fg,
    padding: "120px 0",
    borderTop: theme === "ink" ? "none" : "1px solid rgba(0,16,17,0.08)"
  } }, /* @__PURE__ */ React.createElement("div", { className: "container" }, /* @__PURE__ */ React.createElement("div", { style: {
    display: "grid",
    gridTemplateColumns: "1.4fr 1fr",
    gap: 48,
    alignItems: "center"
  } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h2", { className: "display", style: {
    fontSize: "clamp(30px, 3.5vw, 48px)",
    lineHeight: 1,
    letterSpacing: "-0.02em",
    margin: 0
  } }, title, accent && /* @__PURE__ */ React.createElement(React.Fragment, null, " ", /* @__PURE__ */ React.createElement("span", { style: { color: "var(--tangerine)" } }, accent))), body && /* @__PURE__ */ React.createElement("p", { style: {
    marginTop: 18,
    fontSize: 16.5,
    lineHeight: 1.55,
    color: sub,
    maxWidth: 540
  } }, body)), /* @__PURE__ */ React.createElement("div", { style: {
    display: "flex",
    gap: 12,
    flexWrap: "wrap",
    justifyContent: "flex-end"
  } }, primary && /* @__PURE__ */ React.createElement("a", { href: primary[1], className: "btn btn-primary" }, primary[0], " ", /* @__PURE__ */ React.createElement(ArrowRight, null)), secondary && /* @__PURE__ */ React.createElement(
    "a",
    {
      href: secondary[1],
      className: theme === "ink" ? "btn btn-ghost on-dark" : "btn btn-ghost",
      style: { color: theme === "ink" ? "var(--parchment)" : "var(--ink)" }
    },
    secondary[0]
  )))));
};
const featureIcon = (label = "") => {
  const l = String(label).toLowerCase();
  const p = { width: 30, height: 30, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "round", strokeLinejoin: "round" };
  if (l.includes("best") || l.includes("ideal")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("circle", { cx: "9", cy: "8", r: "3" }), /* @__PURE__ */ React.createElement("path", { d: "M3.5 20a5.5 5.5 0 0 1 11 0" }), /* @__PURE__ */ React.createElement("path", { d: "M16 5.2a3 3 0 0 1 0 5.6" }), /* @__PURE__ */ React.createElement("path", { d: "M21 20a5.5 5.5 0 0 0-4-5.3" }));
  if (l.includes("style") || l.includes("estilo") || l.includes("option") || l.includes("opcion")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("rect", { x: "3", y: "3", width: "7", height: "7" }), /* @__PURE__ */ React.createElement("rect", { x: "14", y: "3", width: "7", height: "7" }), /* @__PURE__ */ React.createElement("rect", { x: "3", y: "14", width: "7", height: "7" }), /* @__PURE__ */ React.createElement("rect", { x: "14", y: "14", width: "7", height: "7" }));
  if (l.includes("material")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("path", { d: "M12 3 21 8 12 13 3 8Z" }), /* @__PURE__ */ React.createElement("path", { d: "M3 12 12 17 21 12" }), /* @__PURE__ */ React.createElement("path", { d: "M3 16 12 21 21 16" }));
  if (l.includes("lead") || l.includes("time") || l.includes("plazo") || l.includes("tiempo")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("rect", { x: "3", y: "4.5", width: "18", height: "16.5", rx: "2" }), /* @__PURE__ */ React.createElement("path", { d: "M3 9.5h18M8 2.5v4M16 2.5v4" }));
  if (l.includes("start") || l.includes("desde")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("path", { d: "M20.6 13.4 11 3.8a2 2 0 0 0-1.4-.6H4v5.6a2 2 0 0 0 .6 1.4l9.6 9.6a2 2 0 0 0 2.8 0l3.6-3.6a2 2 0 0 0 0-2.8Z" }), /* @__PURE__ */ React.createElement("circle", { cx: "7.7", cy: "7.7", r: "1.2" }));
  if (l.includes("width") || l.includes("ancho")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("path", { d: "M3 12h18M6 9l-3 3 3 3M18 9l3 3-3 3" }));
  if (l.includes("height") || l.includes("altura")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("path", { d: "M12 3v18M9 6l3-3 3 3M9 18l3 3 3-3" }));
  if (l.includes("gauge") || l.includes("mesh") || l.includes("calibre")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("path", { d: "M5 5l6 6-6 6M11 5l6 6-6 6" }));
  if (l.includes("finish") || l.includes("color") || l.includes("acabado")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("circle", { cx: "9", cy: "9", r: "5" }), /* @__PURE__ */ React.createElement("circle", { cx: "15", cy: "15", r: "5" }));
  if (l.includes("wind") || l.includes("viento")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("path", { d: "M3 8h12a3 3 0 1 0-3-3M3 12h16a3 3 0 1 1-3 3M3 16h9a2.5 2.5 0 1 1-2.5 2.5" }));
  if (l.includes("warrant") || l.includes("garant")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("path", { d: "M12 3 19 6v6q0 5-7 9-7-4-7-9V6Z" }), /* @__PURE__ */ React.createElement("path", { d: "M9 12l2 2 4-4" }));
  if (l.includes("post") || l.includes("spacing") || l.includes("separac")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("path", { d: "M5 4v16M12 4v16M19 4v16" }));
  if (l.includes("hardware") || l.includes("herraj")) return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("path", { d: "M14.7 6.3a3.8 3.8 0 0 0-5 5l-5 5 2 2 5-5a3.8 3.8 0 0 0 5-5l-2.4 2.4-2-.5-.5-2Z" }));
  return /* @__PURE__ */ React.createElement("svg", { ...p }, /* @__PURE__ */ React.createElement("circle", { cx: "12", cy: "12", r: "9" }), /* @__PURE__ */ React.createElement("path", { d: "M12 8h.01M11.5 12h.5v4h1" }));
};
const FeatureRow = ({ items }) => /* @__PURE__ */ React.createElement("div", { style: {
  display: "grid",
  gridTemplateColumns: `repeat(${items.length}, 1fr)`,
  gap: 0,
  background: "var(--white)",
  borderRadius: 16,
  boxShadow: "0 34px 70px -34px rgba(0,16,17,0.4)",
  border: "1px solid rgba(0,16,17,0.06)",
  overflow: "hidden"
} }, items.map(([k, v], i) => /* @__PURE__ */ React.createElement("div", { key: i, style: {
  padding: "28px 26px",
  borderLeft: i === 0 ? "none" : "1px solid rgba(0,16,17,0.08)"
} }, /* @__PURE__ */ React.createElement("div", { "aria-hidden": true, style: { color: "var(--tangerine)", marginBottom: 14 } }, featureIcon(k)), /* @__PURE__ */ React.createElement("div", { className: "mono", style: {
  fontSize: 13.5,
  letterSpacing: "0.18em",
  textTransform: "uppercase",
  color: "var(--tangerine)",
  fontWeight: 700,
  marginBottom: 10
} }, k), /* @__PURE__ */ React.createElement("div", { style: { fontSize: 15.5, lineHeight: 1.55, color: "var(--ink)" } }, v))));
const SplitBlock = ({ kicker, title, accent, body, bullets, image, imageRight = true, dark = false }) => {
  const bg = dark ? "var(--ink)" : "var(--white)";
  const fg = dark ? "var(--parchment)" : "var(--ink)";
  const sub = dark ? "var(--alice-blue)" : "var(--charcoal)";
  return /* @__PURE__ */ React.createElement("section", { className: dark ? "wfs-brand-texture" : void 0, style: { backgroundColor: bg, color: fg, padding: "120px 0" } }, /* @__PURE__ */ React.createElement("div", { className: "container" }, /* @__PURE__ */ React.createElement("div", { style: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 56,
    alignItems: "center"
  } }, /* @__PURE__ */ React.createElement("div", { style: { order: imageRight ? 1 : 2 } }, /* @__PURE__ */ React.createElement("h2", { className: "display", style: {
    margin: 0,
    fontSize: "clamp(28px, 3vw, 42px)",
    lineHeight: 1,
    letterSpacing: "-0.02em",
    fontWeight: 800
  } }, title, accent && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("br", null), /* @__PURE__ */ React.createElement("span", { style: { color: "var(--tangerine)" } }, accent))), body && /* @__PURE__ */ React.createElement("p", { style: {
    marginTop: 18,
    fontSize: 16.5,
    lineHeight: 1.6,
    color: sub,
    maxWidth: 520
  } }, body), bullets && /* @__PURE__ */ React.createElement("ul", { style: {
    margin: "22px 0 0",
    padding: 0,
    listStyle: "none",
    display: "grid",
    gap: 12,
    maxWidth: 520
  } }, bullets.map((b, i) => /* @__PURE__ */ React.createElement("li", { key: i, style: {
    display: "flex",
    alignItems: "flex-start",
    gap: 12,
    fontSize: 15.5,
    lineHeight: 1.5,
    color: fg
  } }, /* @__PURE__ */ React.createElement("span", { style: {
    flexShrink: 0,
    marginTop: 6,
    width: 6,
    height: 6,
    background: "var(--tangerine)"
  } }), b)))), /* @__PURE__ */ React.createElement("div", { style: {
    order: imageRight ? 2 : 1,
    position: "relative",
    aspectRatio: "4 / 3",
    overflow: "hidden",
    background: "#263166"
  } }, image && /* @__PURE__ */ React.createElement(
    "img",
    {
      src: image,
      alt: "",
      style: { position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }
    }
  )))));
};
Object.assign(window, {
  Breadcrumb,
  PageHero,
  PageSectionHeader,
  StatStrip,
  CTABand,
  FeatureRow,
  SplitBlock
});
const UseCaseRow = ({ title, body, badge, index }) => {
  const [hover, setHover] = React.useState(false);
  return /* @__PURE__ */ React.createElement(
    "a",
    {
      href: "estimate.html",
      className: "wfs-usecase-row",
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      style: {
        display: "grid",
        gridTemplateColumns: "104px 1.15fr 1fr 48px",
        gap: 28,
        alignItems: "center",
        padding: "32px 22px",
        margin: "0 -22px",
        borderBottom: "1px solid rgba(0,16,17,0.1)",
        textDecoration: "none",
        color: "inherit",
        background: hover ? "rgba(255,113,51,0.07)" : "transparent",
        transition: "background 0.2s ease"
      }
    },
    /* @__PURE__ */ React.createElement("span", { className: "display wfs-usecase-num", "aria-hidden": true, style: {
      fontSize: 61.5,
      lineHeight: 1,
      fontWeight: 800,
      color: hover ? "var(--tangerine)" : "transparent",
      WebkitTextStroke: hover ? "0px transparent" : "1.5px rgba(38,49,102,0.32)",
      transition: "color 0.2s ease"
    } }, "0", index + 1),
    /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "display", style: {
      margin: "0 0 12px",
      fontSize: "clamp(18px, 1.6vw, 24px)",
      lineHeight: 1.1,
      textTransform: "uppercase",
      letterSpacing: "0.01em"
    } }, title), badge && /* @__PURE__ */ React.createElement("span", { className: "mono", style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "6px 12px",
      borderRadius: 4,
      border: "1px solid rgba(46,89,193,0.35)",
      background: hover ? "var(--white)" : "transparent",
      fontSize: 13,
      fontWeight: 700,
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--laser-blue)",
      transition: "background 0.2s ease"
    } }, badge)),
    /* @__PURE__ */ React.createElement("p", { style: { margin: 0, fontSize: 16, lineHeight: 1.6, color: "var(--charcoal)" } }, body),
    /* @__PURE__ */ React.createElement("span", { "aria-hidden": true, style: {
      width: 44,
      height: 44,
      borderRadius: "50%",
      border: `1px solid ${hover ? "var(--tangerine)" : "rgba(0,16,17,0.18)"}`,
      background: hover ? "var(--tangerine)" : "transparent",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      color: hover ? "var(--white)" : "var(--ink)",
      justifySelf: "end",
      transition: "background 0.2s ease, border-color 0.2s ease, color 0.2s ease"
    } }, /* @__PURE__ */ React.createElement("svg", { width: "14", height: "14", viewBox: "0 0 16 16", fill: "none" }, /* @__PURE__ */ React.createElement("path", { d: "M3 8h10m0 0L9 4m4 4l-4 4", stroke: "currentColor", strokeWidth: "1.6", strokeLinecap: "square" })))
  );
};
window.UseCaseRow = UseCaseRow;
