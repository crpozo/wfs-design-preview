const AboutHero = () => {
  const t = useT();
  return /* @__PURE__ */ React.createElement(
    PageHero,
    {
      crumbs: [[t("Home", "Inicio"), "Homepage.html"], [t("About", "Nosotros"), null]],
      eyebrow: t("About \xB7 Western Fence Supply", "Nosotros \xB7 Western Fence Supply"),
      title: t("Family-owned.", "Empresa familiar."),
      accent: t("Fabricated in Fort Myers.", "Fabricado en Fort Myers."),
      subtitle: t("A material supplier for contractors, homeowners and DIY projects across Southwest Florida. We don't install, we stock, fabricate and ship the components your fence is built from.", "Un proveedor de materiales para contratistas, propietarios y proyectos de bricolaje en todo el suroeste de Florida. No instalamos: tenemos en existencia, fabricamos en planta y enviamos los componentes con los que se construye tu cerca."),
      image: "https://crpozo.github.io/wfs-design-preview/assets/wfs-shop.webp"
    }
  );
};
const AboutStory = () => {
  const t = useT();
  return /* @__PURE__ */ React.createElement("section", { style: { background: "var(--white)", padding: "120px 0" } }, /* @__PURE__ */ React.createElement("div", { className: "container" }, /* @__PURE__ */ React.createElement("div", { style: {
    display: "grid",
    gridTemplateColumns: "1.2fr 1fr",
    gap: 56,
    alignItems: "end",
    paddingBottom: 32,
    marginBottom: 64,
    borderBottom: "1px solid rgba(0,16,17,0.12)"
  } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h2", { className: "display", style: {
    margin: 0,
    fontSize: "clamp(28px, 3vw, 44px)",
    lineHeight: 1,
    letterSpacing: "-0.02em",
    fontWeight: 800,
    maxWidth: 640
  } }, t("From contractor's yard", "De la sucursal de un contratista"), " ", /* @__PURE__ */ React.createElement("br", null), /* @__PURE__ */ React.createElement("span", { style: { color: "var(--tangerine)" } }, t("to SW Florida's supply hub.", "al centro de suministro del suroeste de Florida.")))), /* @__PURE__ */ React.createElement("p", { style: {
    margin: 0,
    maxWidth: 420,
    justifySelf: "end",
    textAlign: "right",
    fontSize: 15.5,
    lineHeight: 1.6,
    color: "var(--charcoal)"
  } }, t("A family-run Southwest Florida fence supplier, led by management with two decades of fencing installation and fabrication experience. Two yards in Fort Myers and Port Charlotte, serving customers throughout Florida.", "Un proveedor de cercas familiar del suroeste de Florida, dirigido por un equipo con dos d\xE9cadas de experiencia en instalaci\xF3n y fabricaci\xF3n de cercas. Dos sucursales en Fort Myers y Port Charlotte, al servicio de clientes en toda Florida."))), /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1.3fr", gap: 64, alignItems: "start" } }, /* @__PURE__ */ React.createElement("div", { style: { position: "sticky", top: 120 } }, /* @__PURE__ */ React.createElement("div", { style: {
    position: "relative",
    aspectRatio: "4 / 5",
    overflow: "hidden",
    background: "#263166"
  } }, /* @__PURE__ */ React.createElement(
    "img",
    {
      src: "https://crpozo.github.io/wfs-design-preview/assets/hero-warehouse.webp",
      alt: t("WFS Fort Myers warehouse", "Almac\xE9n de WFS en Fort Myers"),
      style: { position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }
    }
  ), /* @__PURE__ */ React.createElement("div", { "aria-hidden": true, style: {
    position: "absolute",
    inset: 0,
    background: "linear-gradient(180deg, rgba(38, 49, 102,0) 50%, rgba(38, 49, 102,0.55) 100%)"
  } }), /* @__PURE__ */ React.createElement("div", { className: "mono", style: {
    position: "absolute",
    top: 18,
    left: 18,
    background: "var(--tangerine)",
    color: "var(--ink)",
    padding: "5px 10px",
    fontSize: 13.5,
    letterSpacing: "0.22em",
    fontWeight: 700
  } }, t("HQ \xB7 FORT MYERS", "SEDE \xB7 FORT MYERS")), /* @__PURE__ */ React.createElement("div", { style: {
    position: "absolute",
    bottom: 18,
    left: 18,
    right: 18,
    color: "var(--white)"
  } }, /* @__PURE__ */ React.createElement("div", { className: "display", style: { fontSize: 19.5, lineHeight: 1.1 } }, "2621 Fowler St"), /* @__PURE__ */ React.createElement("div", { className: "mono", style: { marginTop: 6, fontSize: 13.5, letterSpacing: "0.18em", color: "rgba(255,255,255,0.85)" } }, "FORT MYERS, FL 33901")))), /* @__PURE__ */ React.createElement("div", { style: { position: "relative", paddingLeft: 56 } }, /* @__PURE__ */ React.createElement("div", { "aria-hidden": true, style: {
    position: "absolute",
    left: 17,
    top: 14,
    bottom: 14,
    width: 1,
    background: "rgba(255,113,51,0.35)"
  } }), [
    ["01", { EN: "Supply only", ES: "Solo suministro" }, { EN: "We are a supply company, not an installer. We sell the material your fence is built from and can recommend trusted local installers for the build.", ES: "Somos una empresa de suministro, no instaladores. Vendemos el material con el que se construye tu cerca y podemos recomendarte instaladores locales de confianza para la obra." }],
    ["02", { EN: "In-house fabrication", ES: "Fabricaci\xF3n en planta" }, { EN: "Gates and custom work are fabricated in-house at our Fort Myers yard.", ES: "Los portones y los trabajos a medida se fabrican en planta, en nuestra sucursal de Fort Myers." }],
    ["03", { EN: "Four fence systems", ES: "Cuatro sistemas de cercas" }, { EN: "Premium vinyl, aluminum, chain link and metal fencing, sold to fence companies and homeowners alike.", ES: "Cercas premium de vinilo, aluminio, malla cicl\xF3nica y metal, para empresas de cercas y propietarios por igual." }],
    ["04", { EN: "Two yards", ES: "Dos sucursales" }, { EN: "Two convenient yard locations in Fort Myers and Port Charlotte, serving customers throughout Florida, including Lee, Collier, Charlotte, Hendry, and surrounding counties.", ES: "Dos sucursales convenientes en Fort Myers y Port Charlotte, al servicio de clientes en toda Florida, incluidos los condados de Lee, Collier, Charlotte, Hendry y los alrededores." }],
    ["05", { EN: "Delivery or pickup", ES: "Entrega o retiro" }, { EN: "Job-site delivery on our own trucks, or same-day pickup on standard qualifying orders.", ES: "Entrega en obra con nuestros propios camiones, o retiro el mismo d\xEDa en pedidos est\xE1ndar que califiquen." }]
  ].map(([y, label, body], i, arr) => /* @__PURE__ */ React.createElement("div", { key: y, style: {
    position: "relative",
    paddingBottom: i === arr.length - 1 ? 0 : 44
  } }, /* @__PURE__ */ React.createElement("span", { "aria-hidden": true, style: {
    position: "absolute",
    left: -45,
    top: 10,
    width: 14,
    height: 14,
    borderRadius: "50%",
    background: "var(--tangerine)",
    border: "3px solid var(--white)",
    boxShadow: "0 0 0 1px rgba(255,113,51,0.5)"
  } }), /* @__PURE__ */ React.createElement("div", { style: {
    display: "grid",
    gridTemplateColumns: "88px 1fr",
    gap: 28,
    alignItems: "baseline"
  } }, /* @__PURE__ */ React.createElement("div", { className: "display", style: {
    fontSize: 31.5,
    lineHeight: 1,
    color: "var(--ink)",
    letterSpacing: "-0.01em"
  } }, y), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "mono", style: {
    fontSize: 13.5,
    letterSpacing: "0.22em",
    textTransform: "uppercase",
    color: "var(--tangerine)",
    fontWeight: 700,
    marginBottom: 10
  } }, t(label)), /* @__PURE__ */ React.createElement("p", { style: {
    margin: 0,
    fontSize: 16.5,
    lineHeight: 1.6,
    color: "var(--ink)",
    maxWidth: 520
  } }, t(body))))))))));
};
const AboutValues = () => {
  const t = useT();
  const rules = [
    [{ EN: "No low-grade material", ES: "Nada de material de baja calidad" }, { EN: "If we wouldn't put it on our own job, we don't stock it. We turn down lower price points every quarter to protect the catalog.", ES: "Si no lo pondr\xEDamos en nuestra propia obra, no lo tenemos en existencia. Cada trimestre rechazamos precios m\xE1s bajos para proteger el cat\xE1logo." }],
    [{ EN: "Real lead-time honesty", ES: "Honestidad real en los tiempos de entrega" }, { EN: "Stocked items ship in 1\u20133 days. Custom orders can be completed in as little as 2 days, depending on the request. We tell you the truth on the first call, no soft dates.", ES: "Los art\xEDculos en existencia se env\xEDan en 1 a 3 d\xEDas. Los pedidos a medida pueden completarse en tan solo 2 d\xEDas, seg\xFAn la solicitud. Te decimos la verdad en la primera llamada, sin fechas imprecisas." }],
    [{ EN: "Pricing without games", ES: "Precios sin juegos" }, { EN: "Same supplier-direct floor for contractors, homeowners and DIY. No minimums, no contractor-only tiers.", ES: "El mismo precio directo de proveedor para contratistas, propietarios y bricolaje. Sin m\xEDnimos, sin niveles exclusivos para contratistas." }]
  ];
  return /* @__PURE__ */ React.createElement("section", { style: { background: "var(--white)", padding: "120px 0" } }, /* @__PURE__ */ React.createElement("div", { className: "container" }, /* @__PURE__ */ React.createElement("div", { className: "mono", style: {
    display: "inline-flex",
    alignItems: "center",
    gap: 12,
    marginBottom: 22,
    fontSize: 14,
    fontWeight: 700,
    letterSpacing: "0.22em",
    textTransform: "uppercase",
    color: "var(--laser-blue)"
  } }, /* @__PURE__ */ React.createElement("span", { "aria-hidden": true, style: { width: 30, height: 3, background: "var(--tangerine)", borderRadius: 2 } }), t("How we operate", "C\xF3mo operamos")), /* @__PURE__ */ React.createElement("div", { style: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 48,
    alignItems: "end",
    paddingBottom: 28,
    borderBottom: "2px solid var(--ink)"
  } }, /* @__PURE__ */ React.createElement("h2", { className: "display", style: {
    margin: 0,
    fontSize: "clamp(30px, 3.4vw, 46px)",
    lineHeight: 1.02,
    letterSpacing: "-0.01em",
    fontWeight: 800,
    textTransform: "uppercase"
  } }, t("Three rules", "Tres reglas"), /* @__PURE__ */ React.createElement("br", null), /* @__PURE__ */ React.createElement("span", { style: { color: "var(--tangerine)" } }, t("we don't break.", "que no rompemos."))), /* @__PURE__ */ React.createElement("p", { style: {
    margin: 0,
    maxWidth: 360,
    justifySelf: "end",
    textAlign: "right",
    fontSize: 16,
    lineHeight: 1.6,
    color: "var(--charcoal)"
  } }, t("Same standard we held when we were the contractors using this material every day.", "El mismo est\xE1ndar que manten\xEDamos cuando \xE9ramos los contratistas que usaban este material todos los d\xEDas."))), rules.map(([label, body], i) => /* @__PURE__ */ React.createElement("div", { key: i, className: "wfs-usecase-row", style: {
    display: "grid",
    gridTemplateColumns: "104px 1fr 1.2fr",
    gap: 28,
    alignItems: "center",
    padding: "34px 0",
    borderBottom: "1px solid rgba(0,16,17,0.1)"
  } }, /* @__PURE__ */ React.createElement("span", { className: "display wfs-usecase-num", "aria-hidden": true, style: {
    fontSize: 61.5,
    lineHeight: 1,
    fontWeight: 800,
    color: "transparent",
    WebkitTextStroke: "1.5px rgba(38,49,102,0.32)"
  } }, "0", i + 1), /* @__PURE__ */ React.createElement("h3", { className: "display", style: {
    margin: 0,
    fontSize: "clamp(18px, 1.6vw, 24px)",
    lineHeight: 1.1,
    textTransform: "uppercase",
    letterSpacing: "0.01em"
  } }, t(label)), /* @__PURE__ */ React.createElement("p", { style: { margin: 0, fontSize: 16, lineHeight: 1.6, color: "var(--charcoal)" } }, t(body))))));
};
const AboutShop = () => {
  const t = useT();
  return /* @__PURE__ */ React.createElement(
    SplitBlock,
    {
      kicker: t("In-house fabrication", "Fabricaci\xF3n en planta"),
      title: t("Welded, cut and", "Soldado, cortado y"),
      accent: t("packed in Fort Myers.", "empacado en Fort Myers."),
      body: t("Most of our gates ship ready-to-assemble from our fabrication shop. Aluminum, chain link, metal, vinyl and EC Fence, cut and welded to spec in-house, so what arrives on your jobsite is ready to install the same day.", "La mayor\xEDa de nuestros portones se env\xEDan listos para armar desde nuestro taller de fabricaci\xF3n. Aluminio, malla cicl\xF3nica, metal, vinilo y EC Fence, cortados y soldados a la medida en planta, para que lo que llega a tu obra est\xE9 listo para instalar el mismo d\xEDa."),
      bullets: [
        t("Custom gate fabrication, up to 30 ft cantilever", "Fabricaci\xF3n de portones a medida, hasta 30 ft en cantilever"),
        t("Hardware kits packed and labeled to the order", "Kits de herrajes empacados y etiquetados seg\xFAn el pedido"),
        t("Powder-coat color-match on aluminum runs", "Igualaci\xF3n de color con pintura en polvo en producciones de aluminio"),
        t("Same-day pickup on stocked panels and components", "Retiro el mismo d\xEDa de paneles y componentes en existencia")
      ],
      image: "https://crpozo.github.io/wfs-design-preview/assets/wfs-shop.webp",
      imageRight: true,
      dark: true
    }
  );
};
const AboutStats = () => {
  const t = useT();
  const stats = [
    ["20+", { EN: "Years experience", ES: "A\xF1os de experiencia" }, { EN: "Fencing install + fabrication", ES: "Instalaci\xF3n y fabricaci\xF3n de cercas" }],
    ["4", { EN: "Fence materials", ES: "Materiales de cerca" }, { EN: "Vinyl \xB7 Aluminum \xB7 Chain link \xB7 Metal", ES: "Vinilo \xB7 Aluminio \xB7 Malla cicl\xF3nica \xB7 Metal" }],
    ["2", { EN: "Yards", ES: "Sucursales" }, { EN: "Fort Myers + Port Charlotte", ES: "Fort Myers + Port Charlotte" }],
    ["FL", { EN: "Statewide service", ES: "Servicio estatal" }, { EN: "Serving customers throughout Florida", ES: "Atendemos clientes en toda Florida" }],
    [{ EN: "Lifetime", ES: "De por vida" }, { EN: "Warranty", ES: "Garant\xEDa" }, { EN: "On most materials we sell", ES: "En la mayor\xEDa de los materiales que vendemos" }]
  ];
  return /* @__PURE__ */ React.createElement("section", { style: { background: "var(--white)", padding: "120px 0" } }, /* @__PURE__ */ React.createElement("div", { className: "container" }, /* @__PURE__ */ React.createElement("div", { style: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "baseline",
    gap: 32,
    flexWrap: "wrap",
    paddingBottom: 28,
    marginBottom: 56,
    borderBottom: "1px solid rgba(0,16,17,0.12)"
  } }, /* @__PURE__ */ React.createElement("div", { style: {
    display: "flex",
    alignItems: "baseline",
    gap: 14
  } }, /* @__PURE__ */ React.createElement("span", { className: "display", style: {
    fontSize: 23.5,
    lineHeight: 1,
    color: "var(--ink)"
  } }, t("Family-owned and run.", "De propiedad y gesti\xF3n familiar.")), /* @__PURE__ */ React.createElement("span", { style: { fontSize: 15, color: "var(--charcoal)" } }, t("Two yards, zero plans to franchise.", "Dos sucursales, cero planes de franquiciar.")))), /* @__PURE__ */ React.createElement("div", { style: {
    display: "grid",
    gridTemplateColumns: `repeat(${stats.length}, 1fr)`,
    gap: 0
  } }, stats.map(([n, label, sub], i) => /* @__PURE__ */ React.createElement("div", { key: label.EN, style: {
    padding: i === 0 ? "0 28px 0 0" : `0 28px`,
    borderLeft: i === 0 ? "none" : "1px solid rgba(0,16,17,0.12)"
  } }, /* @__PURE__ */ React.createElement("div", { className: "display", style: {
    fontSize: "clamp(48px, 5.4vw, 80px)",
    lineHeight: 1,
    color: "var(--ink)",
    letterSpacing: "-0.02em"
  } }, t(n)), /* @__PURE__ */ React.createElement("div", { style: {
    marginTop: 22,
    fontSize: 15.5,
    fontWeight: 600,
    color: "var(--ink)",
    letterSpacing: "-0.005em"
  } }, t(label)), /* @__PURE__ */ React.createElement("div", { className: "mono", style: {
    marginTop: 6,
    fontSize: 14,
    letterSpacing: "0.08em",
    color: "var(--charcoal)",
    lineHeight: 1.5
  } }, t(sub)))))));
};
const AboutCTA = () => {
  const t = useT();
  return /* @__PURE__ */ React.createElement(
    CTABand,
    {
      kicker: t("Visit the yard", "Visita la sucursal"),
      title: t("Walk the shop,", "Recorre el taller,"),
      accent: t("meet the team.", "conoce al equipo."),
      body: t("Both yards are open Monday-Friday 7am-4pm and Saturday 7am-12pm. Call ahead and we'll have your materials staged when you pull in.", "Ambas sucursales abren de lunes a viernes de 7am a 4pm y los s\xE1bados de 7am a 12pm. Llama con anticipaci\xF3n y tendremos tus materiales listos cuando llegues."),
      primary: [t("Get a quote", "Obt\xE9n una cotizaci\xF3n"), "estimate.html"],
      secondary: [t("Yard locations", "Ubicaciones de sucursales"), "solutions.html#yards"]
    }
  );
};
Object.assign(window, { AboutHero, AboutStory, AboutValues, AboutShop, AboutStats, AboutCTA });
